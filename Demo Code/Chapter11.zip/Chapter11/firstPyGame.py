import pygame as pg
import pygame_color_simple as clr
pg.init()

root = pg.display.set_mode((800, 600))
root.fill(clr.lime)
pg.display.set_caption("First PyGame Example")

clock = pg.time.Clock() 
done = False
while not done: 
    time_passed = clock.tick(30)
    for event in pg.event.get(): 
        if event.type == pg.QUIT: 
            done = True
    pg.display.update()

print("Program terminated.")
pg.quit() 