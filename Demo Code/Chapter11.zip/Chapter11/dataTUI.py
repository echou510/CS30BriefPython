
count = 0

def main(): 
    global count
    while True: 
        if count==100: break 
        print(count)
        count += 1 

if __name__ == "__main__": 
    main()
