import pygame as pg
import pygame_color_simple as clr

class game: 
    def __init__(self, title, w, h, bg):
        self.title = title
        self.w = w
        self.h = h
        self.bg = bg
        self.data_init()

    def data_init(self): 
        self.count = 0

    def run(self):
        root = pg.display.set_mode((self.w, self.h))
        root.fill(clr.moon_glow)
        pg.display.set_caption(self.title)
        clock = pg.time.Clock() 

        done = False
        while not done: 
            time_passed = clock.tick(30)
            for event in pg.event.get((pg.KEYUP, pg.QUIT)):
                if event.type == pg.QUIT:
                    done = True
                if event.type == pg.KEYUP:
                    if event.key == pg.K_DOWN:
                        print("down")
                    if event.key == pg.K_SPACE:
                        print("space")
                    if event.key == pg.K_RIGHT:
                        print("Right ->")
                    if event.key == pg.K_LEFT:
                        print("Left <-")

            pg.display.update()
            self.count += 1
            #print(self.count)

def main(): 
    pg.init()
    g = game("Keyboard", 800, 600, clr.lime)
    g.run() 
    pg.quit()

if __name__ == "__main__": 
    main()