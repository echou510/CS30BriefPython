import pygame as pg
import pygame_color_simple as clr
import random

class game: 
    def __init__(self, title, bg, r, c):
        self.title = title
        
        self.bg = bg
        self.row = r
        self.col = c                    # number of rows and column
        self.size = 60                  # block size
        self.zero = (self.size/2, self.size/2)    # first block's center point
        self.wing = self.size/2 - 2         # half the length of a block side
        self.w = c * self.size
        self.h = r * self.size

    def draw_block(self, root, i, j, color):
        pg.draw.rect(root, color, ((self.zero[0]-self.wing+j*60), (self.zero[1]-self.wing+i*60), self.wing*2, self.wing*2))

    def clear_block(self, root, i, j):
        draw_block(root, i, j, self.bg, self.wing)

    def run(self):
        root = pg.display.set_mode((self.w, self.h))
        root.fill(self.bg)
        pg.display.set_caption(self.title)
        clock = pg.time.Clock() 
        pg.mixer.music.load('vignette.mp3')
        pg.mixer.music.play(0, 0.0)
        pg.time.delay(3000)        

        done = False
        while not done: 
            time_passed = clock.tick(30)
            for event in pg.event.get((pg.KEYUP, pg.QUIT)):
                if event.type == pg.QUIT:
                    pg.mixer.music.load('game_over.mp3')
                    pg.mixer.music.play(-1, 0.0)
                    pg.time.delay(3000)
                    pg.mixer.music.stop()
                    done = True
                if event.type == pg.KEYUP:
                    if event.key == pg.K_DOWN:
                        print("down")
                    if event.key == pg.K_SPACE:
                        i = random.randint(0, self.row-1)  # random row
                        j = random.randint(0, self.col-1)  # random column
                        k = random.randint(0, 9)      # random color
                        re = random.randint(0, 255)
                        gr = random.randint(0, 255)
                        bl = random.randint(0, 255)
                        self.draw_block(root, i, j, (re, gr, bl))
                        print("space")
                    if event.key == pg.K_p:
                        pg.mixer.music.stop()
                        for i in range(self.row):         # clear all all rows and all columns
                            for j in range(self.col):
                                self.draw_block(root, i, j, self.bg)
                        pg.mixer.music.load('tada.mp3')
                        pg.mixer.music.play(-1, 0.0)
                        pg.time.delay(1500)
                        pg.mixer.music.stop()
                        print("p key")
                    if event.key == pg.K_RIGHT:
                        print("Right ->")
                    if event.key == pg.K_LEFT:
                        print("Left <-")

            pg.display.update()

def main(): 
    pg.init()
    g = game("Keyboard", clr.black, 12, 6)
    g.run() 
    pg.quit()

if __name__ == "__main__": 
    main()