import pygame as pg
# data
count = 0

def data_init(x): 
    global count
    count = x

# GUI
width = 800
height = 600
cycle_time = 200

def main(): 
    global count, width, height, cycle_time
    data_init(50)
    pg.init()

    screen = pg.display.set_mode((width, height))
    screen.fill((255, 255, 255))
    pg.display.set_caption("Data")
    clock = pg.time.Clock() 

    done = False
    while not done:
        # hold screen  
        time_passed = clock.tick(cycle_time)
        # handle event 
        for event in pg.event.get(): 
            if event.type == pg.QUIT: 
                done = True 
        # update
        pg.display.update()
        print(count)
        count += 1

    pg.quit() 

if __name__ == "__main__": 
    main()