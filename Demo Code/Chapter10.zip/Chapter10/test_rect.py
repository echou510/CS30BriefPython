import rect


def main():
    r = rect.rect()
    print(r)

if __name__ == "__main__":
    main()
