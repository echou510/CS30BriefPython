import pprint
class rect:
    X = 1000   # static variable
    def __init__(self, left=0, top=0, width=0.0, height=0.0):    # instance self similar to this
        self.left = left
        self.top = top
        self.width = width
        self.height = height

    def getLeft(self): return self.left
    def getTop(self): return self.top
    def getWidth(self): return self.width
    def getHeight(self): return self.height
    def setLeft(self, left): self.left = left
    def setTop(self, top): self.top = top
    def setWidth(self, width): self.width = width
    def setHeight(self, height): self.height = height
    def printX(self): print(rect.X)

    @staticmethod
    def pX(): print(rect.X*2)

    def __eq__(self, other):  # overrider ==
        return self.left==other.left and self.top == other.top \
               and self.width == other.width and self.height == other.height
    def __repr__(self):    # re-print, to_string()
        return "Rect[%d, %d, w=%-6.2f, h=%-6.2f]" % (self.left, self.top, self.width, self.height)
    def __str__(self):    # stronger string type converter
        return "Rect[%d,%d,w=%-6.2f,h=%-6.2f]" % (self.left, self.top, self.width, self.height)

# public static void main(String[] args){}
def main():
    r1 = rect(0, 0, 100, 200)
    print(r1)
    s = str(r1)
    print(s)
    r2 = rect(0, 0, 100, 200)
    r3 = rect(1, 1, 100, 200)
    print((r1==r2))
    print((r1==r3))
    print(r1.getWidth())
    pprint.pprint(dir(r1))
    pprint.pprint(r1.__dict__)
    print(r1.__module__)
    print(rect.X)
    r1.printX()
    rect.pX()
    del r1
    print(r1)

if __name__ == "__main__":
    main()