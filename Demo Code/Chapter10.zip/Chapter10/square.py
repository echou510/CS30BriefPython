from rect import *
class square(rect):
    def __init__(self, left=0, top=0, side=0.0):
        super(square, self).__init__(left, top, side, side)

    def getSide(self): return self.getWidth()
    def setSide(self, side):
        self.setWidth(side)
        self.setHeight(side)
    def __repr__(self):    # re-print, to_string()
        return "Square[%d, %d, w=%-6.2f]" % (self.left, self.top, self.getSide())
    def __str__(self):    # stronger string type converter
        return "Square[%d,%d,s=%-6.2f]" % (self.left, self.top, self.getSide())

def main():
    a = square(10, 10, 100)
    print(a)

if __name__ == "__main__":
    main()