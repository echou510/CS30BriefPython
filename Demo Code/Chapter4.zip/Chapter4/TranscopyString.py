fin = open("aa.txt", "r")
fout = open("bb.txt", "w")

fstr = fin.read()     # read(): read the whole file to a string.

print(fstr)

fout.write(fstr)

fout.close()
fin.close()
