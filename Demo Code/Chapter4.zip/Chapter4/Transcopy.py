fin = open("aa.txt", "r")
fout = open("bb.txt", "w")

ch = fin.read(1)     # read(1) read one character
while ch:
    print(ch, end="")
    fout.write(ch)   # write(ch), ch is a single character.
    ch = fin.read(1)

fout.close()
fin.close()
