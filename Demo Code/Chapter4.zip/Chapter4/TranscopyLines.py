fin = open("aa.txt", "r")
fout = open("bb.txt", "w")

lines = fin.readlines()     # readlines() read in the whole files in
                            # a list of lines
for line in lines:
    print(line, end="")
    fout.write(line)   # write(line), line is a single line.

fout.close()
fin.close()
