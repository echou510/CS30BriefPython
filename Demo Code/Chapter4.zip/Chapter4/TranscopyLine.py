fin = open("aa.txt", "r")
fout = open("bb.txt", "w")

line = fin.readline()     # readline() read one line
while line:
    print(line, end="")
    fout.write(line)   # write(line), line is a single line.
    line = fin.readline()

fout.close()
fin.close()
