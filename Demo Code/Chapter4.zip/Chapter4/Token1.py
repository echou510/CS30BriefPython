import pprint
fin = open("oahufood.csv", "r")
#fout = open("bb.txt", "w")

line = fin.readline().strip()
store =[]
while line:
    tokens = line.strip().split(",")
    name = tokens[0].strip()
    phonenoest = tokens[1].strip()
    email = tokens[2].strip()
    owner = tokens[3].strip()
    address = tokens[4].strip()
    zipcode = tokens[5].strip()
    esttype = tokens[6].strip()
    location = ""
    for i in range(7, len(tokens)):
        location += tokens[i]
    if name[0]=='\"' and name[len(name)-1]=='\"':
        name = name[1:len(name)-1]
    location = location[1:len(location)-1]
    t = (name, phonenoest, email, owner, address, zipcode, esttype, location)
    #print(t)
    store.append(t)
    #print("="*50)
    line = fin.readline().strip()
pprint.pprint(store)
#fout.close()
fin.close()
