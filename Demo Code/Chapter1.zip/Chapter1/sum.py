def sum(arr):
    s = 0
    for i in range(len(arr)):   # for (int i =0; i<arr.length; i++) 
        s += arr[i]
    return s

"""
a = [1, 2, 3, 4, 5]
y = sum(a)
print(y)
"""

a = [1, 2]
y = sum(a)
print(a, y)
        
