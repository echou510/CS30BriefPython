import math
plist = [(1, 2), (2, 3), (0, 3), (-1, 3)]

d = -999999999
mi = -1
mj = -1
for i in range(0, len(plist)-1):
    for j in range(1, len(plist)):
        x1 = plist[i][0]
        y1 = plist[i][1]
        x2 = plist[j][0]
        y2 = plist[j][1]        
        dis = math.sqrt((x1-x2)**2 + (y1-y2)**2)
        if dis>d:
            d = dis
            mi = i
            mj = j

print("Point: %s and %s has max distance %.2f" % (plist[mi], plist[mj], d))            
