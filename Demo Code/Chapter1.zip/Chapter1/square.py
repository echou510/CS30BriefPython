def square(x): 
    y = 2*x**2 + 3*x + 1 
    return y

a =3
y = square(a)
print(y)
