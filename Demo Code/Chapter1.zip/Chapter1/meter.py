def mtoy(m):
    return m*1.09361

#  System.out.print("Input a number (in meter):");  
#  String meterStr = input.next(); 
meterStr = input("Input a number (in meter):")

# int meter = Integer.parseInt(meterStr); 
meter = float(meterStr)

# System.out.printf("%.2f meter is %.2f yards\n", meter, mtoy(meter)); 
print("%.2f meter is %.2f yards" % (meter, mtoy(meter)))
