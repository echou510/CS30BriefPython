import main2 
def main():
    y = main2.sq(3)
    print("Data: %d" % y)  # printf 

if __name__ == "__main__":   # public static void main(String[] args){} 
    main()
