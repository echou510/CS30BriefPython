def sq(x):
    return x**2

def cube(x):
    return x**3

def main():
    print(sq(2))
    print(cube(3))

if __name__ == "__main__":
    main()
