import sqlite3
from sqlite3 import Error


def create_connection(db_file):
    conn = None
    try:
        conn = sqlite3.connect(db_file)
    except Error as e:
        print(e)

    return conn


def delete_player(conn, pid):
    sql = 'DELETE FROM player WHERE pid=?'
    cur = conn.cursor()
    cur.execute(sql, (pid,))
    conn.commit()


def main():
    database = r"C:\Eric_Chou\eC Learning\CSP2020_21\PyDev\PyCharm\Chapter12\baseball\baseball.db"

    # create a database connection
    conn = create_connection(database)
    with conn:
        delete_player(conn, 2);

if __name__ == '__main__':
    main()