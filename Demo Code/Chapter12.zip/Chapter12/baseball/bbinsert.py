import sqlite3
from sqlite3 import Error


def create_connection(db_file):
    conn = None
    try:
        conn = sqlite3.connect(db_file)
    except Error as e:
        print(e)

    return conn


def create_team(conn, team):
    sql = ''' INSERT INTO "Team" VALUES (?,?,?) '''

    cur = conn.cursor()
    cur.execute(sql, team)
    conn.commit()
    return cur.lastrowid


def create_player(conn, player):
    sql = ''' INSERT INTO "Player" VALUES (?,?)'''
    cur = conn.cursor()
    cur.execute(sql, player)
    conn.commit()
    return cur.lastrowid


def main():
    database = r"C:\Eric_Chou\eC Learning\CSP2020_21\PyDev\PyCharm\Chapter12\baseball\baseball.db"

    # create a database connection
    conn = create_connection(database)
    with conn:
        # create a new team
        team0 = (1,'Yankees',1901)
        team0_id = create_team(conn, team0)
        team1 = (2,'Red Sox',1901)
        team1_id = create_team(conn, team1)
        team2 = (3,'Giant',1883)
        team2_id = create_team(conn, team2)

        # create players
        p1 = (1,'Babe Ruth')
        p2 = (2,'Willie Mays')
        p3 = (3,'Barry Bonds')
        
        # create tasks
        create_player(conn, p1)
        create_player(conn, p2)
        create_player(conn, p3)


if __name__ == '__main__':
    main()