import sqlite3
from sqlite3 import Error


def create_connection(db_file):
    conn = None
    try:
        conn = sqlite3.connect(db_file)
    except Error as e:
        print(e)

    return conn


def select_player(conn):
    cur = conn.cursor()
    cur.execute("SELECT * FROM player")

    rows = cur.fetchall()

    for row in rows:
        print(row)




def main():
    database = r"C:\Eric_Chou\eC Learning\CSP2020_21\PyDev\PyCharm\Chapter12\baseball\baseball.db"

    # create a database connection
    conn = create_connection(database)
    with conn:
        print("1. Query all players:")
        select_player(conn)

if __name__ == '__main__':
    main()