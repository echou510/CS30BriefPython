import pprint
zodiac = dict()
zodiac = {
    "rat": 1,
    "ox": 2,
    "tiger": 3,
    "rabbit": 4,
    "dragon": 5,
    "snake": 6,
    "horse": 7,
    "goat": 8,
    "monkey": 9,
    "rooster": 10,
    "dog": 11,
    "pig": 12
    }
pprint.pprint(zodiac)

print(type(zodiac.keys()), "-->",zodiac.keys() )
print(type(zodiac.values()), "-->",zodiac.values() )
print(type(zodiac.items()), "-->",zodiac.items() )
kset = list(zodiac.keys())
print(kset)
vset = list(zodiac.values())
print(vset)
zodiac2 = dict(zip(kset, vset))
pprint.pprint(zodiac2)
