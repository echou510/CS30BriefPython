import math
def dot(v1, v2):
    return v1[1]*v2[1]+v1[0]*v2[0]

def maxmin(x, y):
    return max(a, b), min(a, b)

def mm(x, y): 
    return (max(a, b), min(a, b))

def mindist(p1, p2, p3):
    mind = (p1[0]-p2[0])**2 + (p1[1]-p2[1])**2
    if ( (p1[0]-p3[0])**2 + (p1[1]-p3[1])**2<mind):
        mind = (p1[0]-p3[0])**2 + (p1[1]-p3[1])**2
    if ( (p2[0]-p3[0])**2 + (p2[1]-p3[1])**2<mind):
        mind = (p2[0]-p3[0])**2 + (p2[1]-p3[1])**2    
    return math.sqrt(mind)

    
v1 = (1, -1)
v2 = (3, 3)

print(dot(v1, v2))


a = 4
b = 3
c = 5
maxab, minab = maxmin(a, b)
t = mm(a, b)
print(t)

p1 = (2, 3)
p2 = (3, 4)
p3 = (-1, 2)

d = mindist(p1, p2, p3)
print(d)

blist = [a, b, c]
clist = blist.copy() # deep copy
clist = [x*2 for x in clist]
print(blist)
print(clist)
blist = [a, b, c]
clist = [a, b, c]
a = 0
b = 0
c = 0
print(blist, clist)
blist=[int(2), int(3)]
clist=[int(2), int(4)]
print(blist, clist)

blist = [a, b, c]
clist = blist.copy()
clist[0] = 100
clist[1] = 200
print(blist, clist) 





