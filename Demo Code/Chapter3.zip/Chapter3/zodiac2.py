import pprint
zodiac = dict()
zodiac = {
    "rat": 1,
    "ox": 2,
    "tiger": 3,
    "rabbit": 4,
    "dragon": 5,
    "snake": 6,
    "horse": 7,
    "goat": 8,
    "monkey": 9,
    "rooster": 10,
    "dog": 11,
    "pig": 12
    }

def getAnimal(year):
    for x in zodiac:
        if (zodiac[x]==year): return x
    return None

for animal in zodiac:
    print(zodiac[animal])

for (animal, year) in zodiac.items():
    print(animal,"-->", year)

for k in zodiac.keys():
    print(k)

for v in zodiac.values():
    print(v)

tuples = sorted(zodiac.items(),key=lambda t: t[0], reverse=False)
animal = [t[0] for t in tuples]
year = [t[1] for t in tuples]
zodiac2 = dict(zip(animal, year))
pprint.pprint(zodiac2)
print(getAnimal(7))
del zodiac["goat"]
pprint.pprint(zodiac)
