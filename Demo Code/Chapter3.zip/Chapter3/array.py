import numpy as np
from pylab import *
d = np.ones((3, 3))
print(d)
e = np.zeros((2,2))
print(e)
x = np.zeros(20)
print(x)
print(type(x))
alist = list(x)
print(type(alist))
print(alist)
alist = list(np.ndarray(10))
print("10 Element List: ", alist)

aspace = linspace(-101, 101, 201)
y = []
for a in aspace: y.append(a*a)

figure()
plot(aspace, y, 'b')
show()
