import pprint
data_field = ["ID","Thickness", "Cell Size", "Shape", \
              "Adhesion", "Single Cell", "Nuclei", "Chromatin", \
              "Normal", "MOtoses", "Class"]

print(data_field)

data_set = []
f = open("breast-cancer-wisconsin.csv", "r")

line = f.readline()
while line:
    tokens = line.rstrip().split(',')
    data_num = []
    for i in range(len(tokens)):   # cleansing of the data
        d=0
        if (tokens[i].strip()!='?'): d = int(tokens[i].strip())
        data_num.append(d)
    data_obj = dict(zip(data_field, data_num))
    #pprint.pprint(data_obj)
    data_set.append(data_obj)
    line = f.readline()

print(data_set[0])
classes = [0, 0, 0, 0, 0]
for dic in data_set:
   classes[dic["Class"]] += 1
print(classes)

f.close()
