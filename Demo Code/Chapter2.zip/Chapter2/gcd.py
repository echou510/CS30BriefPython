def gcd(n, m):   # Euclid's Algorithm 
    if (m==0): return n
    return gcd(m, n%m)

print(gcd(48, 32))
print(gcd(32, 48))
print(gcd(97, 65))
print(gcd(51, 15))






