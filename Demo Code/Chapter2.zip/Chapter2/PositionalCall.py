def pp(name="Eric Chou", age=52, score=100):
    print(name, age, score)

print("Case 1: ")
pp()
pp("Tom Cruz")
pp("Tom Cruz", 60)
pp("Tom Cruz", 60, 0)
print()
print("Case 2: ")

pp(age=10, score=54)
pp(score=10, age=32, name="Iron man")
