def isLeapYear(year):
    m400 = year % 400 ==0
    m100 = year % 100 ==0
    m4   = year %   4 ==0
    if (m400): return True   # if (m400) return true
    elif (m100):             # if (m100){ // put statements here
        return False         # }
    elif (m4):
        return True
    else: return False

print("Case 1: ")
for year in range(1900, 2021, 10):
    print("Year %d is a leap year is %s" % (year, str(isLeapYear(year))))

print()
print("Case 2:")
for year in range(1900, 2021, 50):
    print("Year %d is a leap year is %s" % (year, str(isLeapYear(year))))

print()   # System.ou.println()
print("Case 3-special years:")
for year in {1: "Jesus", 1492:"Columbus", 1812:"British Invasion", 1945:"2nd World War"}:
    print("Year %d is a leap year is %s" % (year, str(isLeapYear(year))))

cs_courses = {
 "Data Sciece": "CS 100",
 "Data Strcuture": "CS 200",
 "C language": "CS 45"
}

# for (int i=0; i<100; i++) no regular for-loop
for subject in cs_courses:
    print(subject, end="->")   # System.out.print(subject+"->")
    cnum = cs_courses[subject]
    print(cnum, end="\n")      # print(cnum) === print(cnum, end="\n")

a = [1, 2, 3, 4]
c = 0
for num in a:
    if (c==0): print("[", end="")
    if (c==len(a)-1): print(num, end="]")   # len(a) --> a.length, or a.length(), or a.size() in java
    else: print(num, end=", ")
    c += 1      # no c++

    
