from pylab import *
import math
def diff(f, x, h):    # df/dx
    return (f(x+h)-f(x))/h


x = []    # x is a list
for t in range(-100, 100, 1):
    x.append(t/100*math.pi)

print(x)

y = []
dfdx = []
f = math.sin
for xt in x:
    y.append(f(xt))    #append: adding an element to a list
    dfdx.append(diff(f, xt, 0.000001))

print(dfdx)

figure()
plot(x, y, 'b')
plot(x, dfdx, 'r')
show()

