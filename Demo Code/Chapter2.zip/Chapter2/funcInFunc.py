def maxRow(m):
    def sum(row):   # function inside a funtion
        s = 0
        for e in row:
            s+=e
        return s
            
    maxsum = -999999999
    for r in m:
        sr = sum(r)
        if (sr>maxsum):
            maxsum = sr
    return maxsum



m =[[1, 2, 3], [4, 5, 6], [7, 8, 9]]

print(maxRow(m))
