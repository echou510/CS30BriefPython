import sys

def main():
    print("before loop")
    for i in range(0, 20, 2):
        if (i==6): sys.exit(0)    # terminate the whole program
        print(i)
    print("after loop") 

if __name__ == "__main__":
    main()   # do nothing 
