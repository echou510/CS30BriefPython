def main():
    for i in range(0, 20, 2):
        print(i)

if __name__ == "__main__":
    pass   # do nothing 
