def xyz_there(str):
  i = index(str, "xyz")
  if i<0 : 
    return False
    
  while i!=-1: 
    if i==0: return True
    if str[i-1]=='.': str=str[i+3:]
    else: return True
    i = index(str, "xyz")
  return False  
    
def index(str, word): 
  if (len(str)<len(word)): return -1
  for i in range(0, len(str)-len(word)+1): 
    if (str[i:i+len(word)]==word): return i
  return -1

print(index("abcxyz", "xyz"))
