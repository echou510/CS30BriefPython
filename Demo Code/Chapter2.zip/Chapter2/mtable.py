def m(num):
    for i in range(1, num):
        for j in range(1, num):
            if (num==10): print("%3d" % (i*j), end="")
            if (num==8) : print("%3s" % oct(i*j)[-2:], end="")
            if (num==16): print("%3s" % hex(i*j)[-2:], end="")
        print()

m(8)
print()
m(10)
print()
m(16)
print()

"""
x = 7
bx = "{0:b}".format(x)
print("{0:b}".format(x))
"""
"""
"%d - %d" % (a, b)
====
String.format("%d - %d", a, b);
"""
