def f1():  # abstract function: no implementation 
    pass

def f2():
    pass

def f3():
    pass

f = f1

def main():
    for i in range(0, 20, 2):
        print(i)
    f()

if __name__ == "__main__":
    main()   # do nothing 
