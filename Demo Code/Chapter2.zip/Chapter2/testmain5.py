import sys

def main():
    print("before loop")
    for i in range(0, 20, 2):
        if (i==6): break    # terminate the function
        print(i)
    print("after loop") 

if __name__ == "__main__":
    n = main()   # do nothing
    print(n)     # None similar to null 
