import pprint
f = open("declar.txt", "r")

letter = [chr(i+97) for i in range(26)] # comprehensive list 
print(letter)
freq = [0 for i in range(26)]  # declare 26 integer in an array

line = f.readline()
while line:
    for ch in line.strip().lower():
        if (ch.islower()):
            freq[ord(ch)-ord('a')]+=1
    line = f.readline()

hist = dict(zip(letter, freq))
pprint.pprint(hist)

#print(hist)
f.close() 
