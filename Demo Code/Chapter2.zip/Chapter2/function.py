# function
# pyhton function is an object

def f():
    print(1)

def g():
    print(2)

def h():
    print(3)

t = g
t()
#g = 5
#g()
