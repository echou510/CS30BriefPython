num = 0
done = False
while not done: 
    try:
        num = int(input("Enter an integer: "))
        done = True
    except:
        print("Something wrong")

print("Input number: ", num)

# sorry no do-while loop.
# no traditional for-loop.
"""
Scanner input = new Scanner(System.in); 
int num = 0;
boolean done = false;
while (!done){
   try{
     System.out.print("Enter an integer: ");
     num = Integer.parseInt(input.nextLine());
     done = true; 
   }
   catch(Exception e){
     System.out.println("Something wrong. "); 
   }
}

System.out.println("Input number: "+num); 
"""
