def traffic():
    color = "green"
    ns ={ "green": "yellow", 
         "yellow": "red",
         "red": "green"
        }
    c = 0;
    while c<10:
        print(color)
        color = ns[color]   # next state
        c+=1

def sum(a):
    s = 0
    for i in range(len(a)):   # for (int i=0; i<a.length; i++)
        print(a[i])
        s = s + a[i]
    return s

def main():
    traffic()
    print(sum([3, 4, 5, 6, 7]))
    #print(sum("abcdef"))
    #print(sum({'a':1, 'b':2}))

if __name__== "__main__":
    main()
