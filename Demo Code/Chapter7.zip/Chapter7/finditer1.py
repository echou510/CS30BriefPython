import re

s = "a ab aaab a ab ab b a a a"
slist = re.finditer("a*b",s)
pat = []
indice = []
for m in slist:
    pat.append(m.group(0))
    indice.append(m.start())
    
print(pat)
print(indice)
t = list(zip(pat, indice))
dic = dict(zip(pat, indice))
print(t)
print(dic)
