import re
import pprint
emailChecker = re.compile("[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}")
#emailChecker = re.compile("\w+@\w+\.\w+")

f = open("email.txt", "r")

line = f.readline()
valid = []
while line:
    s = line.strip().lower()
    m = emailChecker.match(s)
    if m:
        valid.append(m.group(0))
    line = f.readline()

pprint.pprint(valid)
print(len(valid))
