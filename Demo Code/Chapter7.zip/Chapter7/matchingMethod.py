import re

s=["", "", ""]
s[0] = "aa ab ab aaab ab ab aaab"
s[1] = "aaa aaaaab a a ab ab abbbb"
s[2] = "aba abbbb ab ab abb abbb"

matching = re.compile("(a+b)")

print("match:")
for i in range(len(s)):
    print("Case %d" % i, end=": ")
    m = matching.match(s[i])
    if m:
        print(m.group(0))
    else: print()

print("search:")
for i in range(len(s)):
    print("Case %d" % i, end=": ")
    m = matching.search(s[i])
    if m:
        print(m.groups())
    else: print()

print("finditer:")
for i in range(len(s)):
    print("Case %d" % i, end=": ")
    mlist = matching.finditer(s[i])
    pat = []
    indice = []
    for m in mlist:
        pat.append(m.group(0))
        indice.append(m.start())
    t = list(zip(pat, indice))
    print(t)
