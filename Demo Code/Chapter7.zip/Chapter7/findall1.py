import re

s = "abaabaaababab"
ablist = re.findall("a+b", s)
if ablist:
    print(ablist)

m = re.search("(a+b)", s)
if m:
    print(m.groups())
