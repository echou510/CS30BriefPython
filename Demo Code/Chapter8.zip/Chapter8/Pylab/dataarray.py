from  pylab import *
import math
#import numpy as np
#import matplotlib.pyplot as plt

x = linspace(1, 3, 3)
y = x**2

w = array([1, 2, 3])
z = x**2

print(x)
print(y)
print(w)
print(z)

x = linspace(-math.pi, math.pi, 1000)
c = np.cos(x)
s = np.sin(x)

figure()
title("Sinusoidal Function")
xlim(xmin=-math.pi*1.1, xmax=math.pi*1.1)        # set x-axis range
ylim(ymin=-1.1, ymax=1.1)
grid(linestyle='-', linewidth='0.5', color='gray')
axhline(0, color='black', lw=2.0)
axvline(0, color='black', lw=2.0)
plot(x, c, 'r')
plot(x, s, 'b')
show()