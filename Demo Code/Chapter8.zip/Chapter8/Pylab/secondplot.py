import matplotlib.pyplot as plt
import numpy as np
def cube(x):
    y = np.array([t**3 for t in x])
    return y

a = np.array([0, 1, 2, 3, 4, 5, 6, 7, 8, 9])

b = a**2
c = cube(a)

plt.figure()
plt.plot(a, b, 'b')      # line chart
plt.scatter(a, c)   # scatter chart
plt.bar(a, b)
plt.show()