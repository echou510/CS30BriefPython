from pylab import *
def cube(x):
    y = array([t**3 for t in x])
    return y

a = array([0, 1, 2, 3, 4, 5, 6, 7, 8, 9])

b = a**2
c = cube(a)

figure()
plot(a, b, 'b')      # line chart
scatter(a, c)   # scatter chart
bar(a, b)
show()