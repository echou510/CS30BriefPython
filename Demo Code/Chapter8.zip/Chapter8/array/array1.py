import numpy as np
import numpy.random as r
a = np.array([1, 2, 3])
b = np.array(["A", "B", "C"])
c = np.array(["Name: ", "Eric", 34])   # the data type can be mixed

print(a)
print(b)
print(c)

d = np.array([
    [1, 2, 3],
    [4, 5],
    [6]
])
print(d)
print(d.shape)
print(d.ndim)

e = list(np.zeros(20))     # int[] e = new int[20]; in Java
print(e)
print(type(e))

f = np.ones(10)
print(f)
print(type(f))

g = np.eye(4)   # identity matrix
print(g)

h = r.random(3)     # random == Math.random()
print(h)

i = r.randint(5, size=30)     # create 3 random Integer in range of [0, 5)
print(i)

j = r.randint(6, size=(3, 3))+1   # create all numbers in [1, 6] in the (3, 3) Matrix
print(j)

ary = np.arange(5)+1   # [1, 5]
r = ary[-1::-1]        # reverse of array
print(ary, "-->", r)
s = "ABCDE"
rstr = s[-1::-1]
print(rstr)            # reverse of string