print("Enter a number: ")  # equivalent to java's println()
a = int(input())           # Integer.parseInt(str)
print(a)

print()   # equivalent to System.out.println();  open a new line

print("Enter a floating point: ", end="")  # equivalent to Java's print()
f = float(input())         # Double.parseDouble(str)
print(f)

print() 
b = int(input("Enter another int: "))
print(b)
print()

s = input("Enter a string: ")   # like input.nextLine()
print()

boo = bool(input("A Boolean Value: ")) # bool: is boolean type 
print(boo)                             # True/False not true/false
print()
