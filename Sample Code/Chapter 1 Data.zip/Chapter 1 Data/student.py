name = input("Enter the student's name: ")
age = int(input("Enter the sutdent's age: "))
math = int(input("Enter math score: "))

print("Name:", name, "  Age:", age, "  Math:", math)

print("Name:", name, end="*"*20)
print("Age:", age)
print("="*100)

