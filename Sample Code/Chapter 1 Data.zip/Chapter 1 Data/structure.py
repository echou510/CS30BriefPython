temp = float(input("Enter Temperature: "))

# Basic If structure:
if temp > 95:
    print("hot")
else:
    if temp > 75:
        print("warm")
    else:
        if temp > 60:
            print("cool")
        else:
            print("cold")            
print()

""" A garbage string is also a comment
 If, elif and else  structure
"""
if temp > 95:
    print("hot")
elif temp > 75:
    print("warm")
elif temp > 60:
    print("cool")
else:
    print("cold")

a = [1, 2, 3, 4, 5]  # a list (array), (arraylist)
for x in a:          # for (int x: a) System.out.println(x); 
    print(x)

print("I am here")

done = False
while not done:
    z = input("Quit? ")
    if (z=="yes"): done = True

def square(x):
    """square: compute the square of a number """
    return x**2     # x**power
    
sq = square(8)
print(sq)

print(square.__doc__)
