#include <iostream> 
using namespace std; 

int main(void){
    bool b = 1 > 2; 
    cout << b << endl; 
    return 0; 
}