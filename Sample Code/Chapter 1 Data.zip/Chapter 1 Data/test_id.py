a = 3
print(a)

def f():
    return 0

a = f
print(a())
print(type(a))
