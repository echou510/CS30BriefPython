a = 3
b = 4
print(a+b)
