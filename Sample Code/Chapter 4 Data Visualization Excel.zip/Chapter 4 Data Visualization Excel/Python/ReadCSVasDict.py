#import necessary modules
import csv

reader = csv.DictReader(open("data.csv"))
for raw in reader:
    print(raw)
