from mpl_toolkits.mplot3d import Axes3D
import matplotlib.pyplot as plt
import numpy as np
from itertools import product, combinations
from geopy import distance
# Data Model
# 38781 Tyson Lane, Fremont, CA 94536
tyson_home = (37.562001,-121.9768045)       # (lat, long) of my home
tlat  = np.deg2rad(tyson_home[0])
tlong = np.deg2rad(tyson_home[1])

xt = np.cos(tlat) * np.cos(tlong)
yt = np.cos(tlat) * np.sin(tlong)
zt = np.sin(tlat)

print("Home  <%7.4f, %7.4f, %7.4f>" % (xt, yt, zt))
# Westminster, London SW1A 1AA, UK
buckingham_palace = (51.5013673,-0.1440787) # (lat, long) of my home
blat  = np.deg2rad(buckingham_palace[0])
blong = np.deg2rad(buckingham_palace[1])

xb = np.cos(blat) * np.cos(blong)
yb = np.cos(blat) * np.sin(blong)
zb = np.sin(blat)
print("Palace<%7.4f, %7.4f, %7.4f>" % (xb, yb, zb))
print()
v = np.array([xt, yt, zt])
w = np.array([xb, yb, zb])
zero = np.array([0, 0, 0])
print("v=", v)
print("w=", w)
vw = np.inner(v, w)
print("v . w=", vw)
v_abs = np.linalg.norm(v-zero)
w_abs = np.linalg.norm(w-zero)
print("|v|=", v_abs)    # both are 1
print("|w|=", w_abs)
print("(vw)/(v_abs*w_abs)=%8.4f" % ((vw)/(v_abs*w_abs)))
print()
theta = np.arccos((vw)/(v_abs*w_abs))
print("theta(deg)=%8.4f\u00B0" % np.rad2deg(theta))
print("theta(rad)=%8.4f (rad)" % theta)
print()
print("Distance(Home, Buckingham Palace)=%10.4f Km" % (6371*theta))
print("Distance(Home, Buckingham Palace)=%10.4f miles" % (6371*theta*0.621371))

# distance calculation by geopy
dis_miles = distance.distance(tyson_home, buckingham_palace).miles
dis_km    = distance.distance(tyson_home, buckingham_palace).km
print("Distance(Home, Buckingham Palace)=%10.4f Km (geopy)" % dis_km)
print("Distance(Home, Buckingham Palace)=%10.4f miles (geopy)" % dis_miles)
# Data Visualization
fig = plt.figure("Earth", figsize=(12, 9))
ax = fig.gca(projection='3d')
ax.set_aspect("equal")

# draw a point
ax.scatter([0], [0], [0], color="g", s=100)
ax.scatter([1], [0], [0], color="k", s=0)
ax.scatter([-1], [0], [0], color="k", s=0)
ax.scatter([0], [1], [0], color="k", s=0)
ax.scatter([0], [-1], [0], color="k", s=0)
ax.scatter([0], [0], [1], color="k", s=0)
ax.scatter([0], [0], [-1], color="k", s=0)
ax.scatter([xt], [yt], [zt], color="r", s=0)
ax.scatter([xb], [yb], [zb], color="b", s=0)

ax.set_xlabel('x')
ax.set_ylabel('y')
ax.set_zlabel('z')
# draw a vector
from matplotlib.patches import FancyArrowPatch
from mpl_toolkits.mplot3d import proj3d

class Arrow3D(FancyArrowPatch):

    def __init__(self, xs, ys, zs, *args, **kwargs):
        FancyArrowPatch.__init__(self, (0, 0), (0, 0), *args, **kwargs)
        self._verts3d = xs, ys, zs

    def draw(self, renderer):
        xs3d, ys3d, zs3d = self._verts3d
        xs, ys, zs = proj3d.proj_transform(xs3d, ys3d, zs3d, renderer.M)
        self.set_positions((xs[0], ys[0]), (xs[1], ys[1]))
        FancyArrowPatch.draw(self, renderer)

a = Arrow3D([0, 1], [0, 0], [0, 0], mutation_scale=20,
            lw=1, arrowstyle="-|>", color="k")
ax.add_artist(a)
c = Arrow3D([0, -1], [0, 0], [0, 0], mutation_scale=20,
            lw=1, arrowstyle="-|>", color="k")
ax.add_artist(c)
d = Arrow3D([0, 0], [0, 1], [0, 0], mutation_scale=20,
            lw=1, arrowstyle="-|>", color="k")
ax.add_artist(d)
e = Arrow3D([0, 0], [0, -1], [0, 0], mutation_scale=20,
            lw=1, arrowstyle="-|>", color="k")
ax.add_artist(e)
f = Arrow3D([0, 0], [0, 0], [0, -1], mutation_scale=20,
            lw=1, arrowstyle="-|>", color="k")
ax.add_artist(f)
g = Arrow3D([0, 0], [0, 0], [0, 1], mutation_scale=20,
            lw=1, arrowstyle="-|>", color="k")
ax.add_artist(g)

ax.text(xt+0.03,yt+0.03,zt+0.03,  '%s' % "Home(37.5,-122.0)", size=12, zorder=1,  color='r')
ht = Arrow3D([0, xt], [0, yt], [0, zt], mutation_scale=20,
            lw=3, arrowstyle="-|>", color="r")
ax.add_artist(ht)
ax.text(xb+0.03,yb+0.03,zb+0.03,  '%s' % "Palace(51.5,-0.1)", size=12, zorder=1,  color='b')
hb = Arrow3D([0, xb], [0, yb], [0, zb], mutation_scale=20,
            lw=3, arrowstyle="-|>", color="b")
ax.add_artist(hb)
plt.show()