from pylab import *
from statistics import mean
f = open("Irma.txt", 'r')
tokens = f.readline().split(',')
for i in range(len(tokens)):
    tokens[i] = tokens[i].strip().lstrip()
    #print(tokens[i])

# assign the title strings
title_dete_time = tokens[0]
title_latitude  = tokens[1]
title_longitude = tokens[2]
title_pressure  = tokens[3]
title_windspeed = tokens[4]
title_stage     = tokens[5]
print("%-14s %-13s %-14s %-12s %-14s %-8s" % (
    title_dete_time,
    title_latitude,
    title_longitude,
    title_pressure,
    title_windspeed,
    title_stage
))

irma_path = []
lines = f.readlines()
for line in lines:
    tokens = line.split(' ')
    d = dict()
    for i in range(len(tokens)):
        tokens[i] = tokens[i].strip().lstrip()
        #print(tokens[i], end=" ")
        d['date'] = int(tokens[0])
        d['hour'] = tokens[2]
        d['location'] = (float(tokens[3]), float(tokens[4]))
        d['pressure'] = int(tokens[5])
        d['wind'] = int(tokens[6])
        d['type'] = tokens[7]
        for j in range(8, len(tokens)):
            d['type'] += " "+tokens[j]

    print("    %-14s %-13.2f %-14.2f %-10d %-14d %-s" % (
        str(""+str(d['date'])+"/"+d['hour']),
        d['location'][0],
        d['location'][1],
        d['pressure'],
        d['wind'],
        d['type']
    ))
    irma_path.append(d)

def category(wind):
    if (wind>=157): return 5
    if (wind>=130): return 4
    if (wind>=111): return 3
    if (wind>=96): return 2
    if (wind>=74): return 1
    return 0

g = open("Irma_cat.txt", "w+")
print()
print()
print("Date:Time          Lat.  Long. Cat.", file=g)
# filtering out non-hurricane points.
for d in irma_path:
    if (category(d['wind']*1.15078)==0):
        del d
    elif (int(d['hour'][:2])%6!=0): del d        # take out extra points
    else:
        d['cat'] = category(d['wind']*1.15078)
        if (d['date']>15): print('2017/08', end='', file=g)
        else: print('2017/09', end='', file=g)
        print("/%02d" % d['date'], end=":", file=g)
        print("[%2s:%2s]" % (d['hour'][:2], d['hour'][2:]), end=' ', file=g)
        print("%5.2f" % d['location'][0], end=' ', file=g)
        print("%5.2f" % d['location'][1], end=' ', file=g)
        print(" %d " % d['cat'], file=g)

lat_list = [d['location'][0] for d in irma_path]
lon_list = [d['location'][1] for d in irma_path]

lon = [i*6 for i in range(len(lon_list)-1)]
lon_diff = [(lon_list[i+1]-lon_list[i]) for i in range(len(lon_list)-1)]
avg = mean(lon_diff)
figure()
title('Hurricane Progress Rate')
xlabel('hour')
ylabel('longitude change')
plot(lon, lon_diff)
show()
print("Total Number of Data Points: ", len(lat_list))
# regression (Exponential Regression)
t = linspace(0, 6*(len(lon_list)-1), len(lon_list))
x = 26.9 + avg * (t//6)
print(x)
print(avg)
a = 16.1
b = 1.013
y = a * b ** (x-26.9)

a1 = 0.000165
b1 = 0.0000013
c1 = 16.1
y1 = a1*t**2 + b1*t + c1

a2 = 0.00000142
b2 = -0.00050
c2 = 0.060
d2 = 16.1
y2 = a2*t**3 + b2*t**2 + c2 * t + d2

print()
print()
print("Date:Time          Lat.  Long. ")
z = 0
for d in irma_path:
    if (d['date'] > 15): print('2017/08', end='')
    else: print('2017/09', end='')
    print("/%02d" % d['date'], end=":")
    print("[%2s:%2s]" % (d['hour'][:2], d['hour'][2:]), end=' ')
    print("%5.2f" % y2[z], end=' ')
    print("%5.2f" % x[z])
    z += 1

import matplotlib.patches as mpatches
figure('Hurricane IRMA Aug.31-Sept.11, 2017', figsize=(8, 6))
xscale('linear')
yscale('linear')
title('Hurricane IRMA Aug.31-Sept.11, 2017')
xlim(20, 100)
ylim(15, 40)
xlabel('longitude(W)')
ylabel('latitude(N)')
scatter(lon_list, lat_list)
plot(x, y, 'r')

scatter([x[0], x[10], x[20], x[30], x[40], x[50], x[58]],
        [y[0], y[10], y[20], y[30], y[40], y[50], y[58]])
plot(x, y1, 'b')
plot(x, y2, 'k')

data_patch = Line2D([], [], marker='o', label='Hurricane Data')
red_patch = mpatches.Patch(color='r', label='Exponential REG')
blue_patch = mpatches.Patch(color='b', label='Quadratic REG')
black_patch = mpatches.Patch(color='k', label='Cubic REG')
legend(handles=[data_patch, red_patch, blue_patch, black_patch], loc=2)
show()