# file1.py
f  = open("aa.txt", "r")
ch = f.read(1)
while ch:
    print(ch, end=" ")
    ch = f.read(1)
f.close()
