print("Iterable Example:")
mylist = [1, 2, 3]
for i in mylist:
    print(i)
print("\n")

print("List Creation by Iterator Example 2:")
mylist = [x*x for x in range(3)]
for i in mylist:
    print(i)
print("\n")

print("Generator Example:")
mygenerator = (x*x for x in range(3))
for i in mygenerator:
    print(i)
print("\n")

print("Yield Example:")
def createGenerator():
    mylist = range(3)
    for i in mylist:
        yield i*i
mygenerator = createGenerator() # create a generator
print(mygenerator) # mygenerator is an object!
for i in mygenerator:
    print(i)


