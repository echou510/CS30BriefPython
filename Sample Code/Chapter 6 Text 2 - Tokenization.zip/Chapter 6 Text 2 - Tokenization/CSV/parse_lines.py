# parse_lines.py
# read a csv file and print the student record to screen.
#
def parse_lines(open_file, sep, conversions):
    for line in open_file:
        yield [conv(item) for conv,item in
                  zip(conversions,line.rstrip('\n').split(sep))]

for fields in parse_lines( open("Student.csv"), ',' , (str,int,int) ):
  print(fields[0], (fields[1]+fields[2])/2)
