# file_remove1.py
# read the whole file into a string
# and, split the string into a list of tokens
# remove all punctuation marks
# remove all digits
# remove all non-letter characters
# remove white space at from and at the end.

f  = open("usdeclar.txt", "r")
text = f.read()
text = text.replace("'s", " ")   # remove all 's
tokens = text.split()
for i in range(len(tokens)):
    new_token = tokens[i]
    for j in range(len(new_token)):
        ch = new_token[j]
        if not (ch.isalpha()):
            new_token = new_token.replace(ch, " ")   # must assign the result back to new_token
    tokens[i] = new_token.strip()

count = 0
for token in tokens:
    if   (count % 20 == 0): print(token, end="")
    elif (count % 20 == 19): print(" "+token)
    else: print(" "+token, end=" ")
    count = count + 1
f.close()