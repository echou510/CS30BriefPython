# spot.py:
# bugs on examples 2, 8, 7 form teacher of ICS 33
def process(word):
    print(word)

print("\n\nExample 1:")
for line in open('file.txt'):
    for word in line.rstrip().lower().split():
        process(word)

print("\n\nExample 2:")
for line in open('file.txt'):
    for word in line.rstrip().split():
        process(word.lower())

print("\n\nExample 3:")
for line in open('file.txt'):
    for word in line.lower().rstrip().split():
        process(word)

# erroneous
print("\n\nExample 4:")
for line in open('file.txt'):
    for word in line.lower().split():
        process(word.rstrip())


print("\n\nExample 5:")
for line in open('file.txt'):
    for word in line.split():
        process(word.rstrip().lower())

print("\n\nExample 6:")
for line in open('file.txt'):
    for word in line.split():
        process(word.lower().rstrip())

print("\n\nExample 7:")
for line in open('file.txt').read().lower().split('\n'):
    for word in line.split():
        process(word)

print("\n\nExample 8:")
for line in open('file.txt').read().split('\n'):
    for word in line.split():
        process(word.lower())
