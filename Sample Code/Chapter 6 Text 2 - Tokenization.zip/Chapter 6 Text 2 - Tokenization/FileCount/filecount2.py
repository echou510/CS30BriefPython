# filecount2.py
# read the whole file into a string
# and, split the string into a list of tokens
# remove all punctuation marks
# remove all digits
# remove all non-letter characters
# remove white space at from and at the end.
# remove meaning less tokens
# conver tokens to lower case
# conver the word list into a non-repeating word list
# When a word is first found, add the word into the word_list and append a one into the occurrence count list.
# When a word is found later, increase the occurrence count number for the token.

f  = open("usdeclar.txt", "r")
text = f.read()
text = text.replace("'s", " ")   # remove all 's
tokens = text.split()      # using regular expression by one or more spaces
for i in range(len(tokens)):
    new_token = tokens[i]
    for j in range(len(new_token)):
        ch = new_token[j]
        if not (ch.isalpha()):
            new_token = new_token.replace(ch, " ")   # must assign the result back to new_token
    tokens[i] = new_token.strip()

# remove empty or meaningless tokens
tokenb = []
for token in tokens:
    token = token.strip()
    token = token.lower()
    if (token != " " and len(token) != 0): tokenb.append(token)
tokens = tokenb

# create non-repeating word list
word_list = []
occurrence = []
for i in range(len(tokens)):
    found = False
    j=0
    while not found and j<len(word_list):
        if (tokens[i]==word_list[j]):
            occurrence[j] += 1
            found = True
        j = j + 1
    if not found:
        word_list.append(tokens[i])
        occurrence.append(1)

leng = len(word_list)
wlist = []
olist = []
for i in range(leng):
    max = -1
    ind = 0
    for j in range(len(occurrence)):
        if (occurrence[j] > max):
            max = occurrence[j]
            ind = j
    wlist.append(word_list[ind])
    olist.append(occurrence[ind])
    del(word_list[ind])
    del(occurrence[ind])

# print out part
tokens    = wlist
occurrence = olist
for i in range(len(tokens)):
    t = "%-20s - %d" % (tokens[i], occurrence[i])
    print(t)

print("\n")
print("Word count in File "+"usdeclar.txt is "+str(len(tokens)))
f.close()