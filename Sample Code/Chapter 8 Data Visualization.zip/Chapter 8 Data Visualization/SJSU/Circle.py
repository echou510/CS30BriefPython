class Circle:
    PI = 3.1415926
    def __init__(self, s, r):
        self.shape = s
        self.radius = r

    def getArea(self):
        return Circle.PI* self.radius * self.radius

    def __repr__(self):
        return "Circle[%.2f]" % self.radius