class EI:
    def __init__(self, y, s):
        self.year = y
        self.ei = s

    def __repr__(self):
        return "(Year=%d, EI=%d)" % (self.year, self.ei)