import json
import pprint
from EI import *
from pylab import *

f = open("sjsu.json", "r")

s = f.read()   # json string
x = json.loads(s)

# first printing
#pprint.pprint(x)

# second printing
elist = []
for entry in x:
    e = EI(entry["year"], entry["EI"])
    elist.append(e)

print(elist)
ylist = []
eilist = []

for e in elist:
    ylist.append(e.year)
    eilist.append(e.ei)

f.close()

figure()
ax = gca()
title("San Jose State Computer Science\nMinimum EI = GPA*800+SAT")
bar(ylist, eilist)
xlabel("Year")
ylabel("Eligibility Index")
ylim(ymin=3800, ymax=5000)
#grid(linestyle='-', linewidth='0.5', color='lightgray')
xticks(np.arange(2012, 2021, step=1))

for x,y in zip(ylist,eilist):
    label = "{:4d}".format(x, y)
    plt.annotate(label, # this is the text
                 (x,y), # this is the point to label
                 textcoords="offset points", # how to position the text
                 xytext=(0,5), # distance from text to points (x,y)
                 ha='center')

show()