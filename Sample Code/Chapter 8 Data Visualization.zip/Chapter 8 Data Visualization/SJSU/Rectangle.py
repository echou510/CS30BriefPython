class Rectangle:
    def __init__(self, s, w, h):
        self.shape = s
        self.width = w
        self.height = h

    def getArea(self):
        return self.width * self.height

    def __repr__(self):
        return "Rectangle[%.2f, %.2f]" % (self.width, self.height)