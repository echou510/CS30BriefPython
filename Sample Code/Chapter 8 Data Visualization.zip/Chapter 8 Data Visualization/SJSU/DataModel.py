import json
import pprint
from Circle import *
from Rectangle import *
f = open("GeoObj.json", "r")

s = f.read()   # json string
x = json.loads(s)

# first printing
pprint.pprint(x)

# second printing
for e in x:
    for key in e:
        print(key, e[key])

# objects
c1 = Circle(x[0]["Shape"], x[0]["Radius"])
print(c1)

r1 = Rectangle(x[1]["Shape"], x[1]["Width"], x[1]["Height"])
print(r1)

f.close()

