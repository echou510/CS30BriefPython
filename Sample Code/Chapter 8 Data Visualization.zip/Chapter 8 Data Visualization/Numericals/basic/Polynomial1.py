from pylab import *
def poly(x):
    return x**4-5*x**2 + 4

x = linspace(-3, 3, 101)
y = poly(x)
figure()         # create a figure
plot(x, y, 'r')  # create x-y plot using red dot
xlabel('x')      # label x-axis
ylabel('y')      # label y-axis
title('4th order Polynomial x^4 - 3x^2 + 4')   #
grid(linestyle='-', linewidth='0.5', color='blue')
axhline(0, color='black', lw=1.0)
axvline(0, color='black', lw=1.0)
show()


