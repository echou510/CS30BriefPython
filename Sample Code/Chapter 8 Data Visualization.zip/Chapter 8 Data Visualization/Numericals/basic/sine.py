from pylab import *

sin_x = []
cos_x = []
# use range function to create sample and create discrete samples.
for x in range(-100, 101, 1):
    z = float(x/100 * 2 * math.pi)
    sin_x.append(sin(z))
    cos_x.append(cos(z))

plot(sin_x)
plot(cos_x)
show()

