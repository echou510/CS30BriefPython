from pylab import *
plot([1,2,3,4])
show()
