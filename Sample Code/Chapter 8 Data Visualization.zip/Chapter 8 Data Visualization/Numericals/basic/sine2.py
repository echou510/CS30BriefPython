from pylab import *

x = linspace(-math.pi*1, math.pi*1, 100)
y = sin(x)
figure()         # create a figure
plot(x, y, 'r')  # create x-y plot using red dot
xlabel('x')      # label x-axis
ylabel('y')      # label y-axis
title('x-y-plot for Sine')   #
show()
