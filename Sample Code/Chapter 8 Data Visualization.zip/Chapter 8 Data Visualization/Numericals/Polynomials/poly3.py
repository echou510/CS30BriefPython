from pylab import *

a = 1
b = 2
c = -2
d = -2
par = [a, b, c, d]
p = poly1d(par)

x = linspace(-6, 6, 101)
y = p(x)      # zero over pole

figure()         # create a figure
xlim(xmin=-5.2, xmax=5.2)        # set x-axis range
ylim(ymin=-5.2, ymax=5.2)           # set y-axis range
plot(x, y, 'r')  # create x-y plot using red dot
xlabel('x')      # label x-axis
ylabel('y')      # label y-axis
title('y =ax^3+bx^2+cx+d')   #
grid(linestyle='-', linewidth='0.5', color='gray')
axhline(0, color='black', lw=1.0)
axvline(0, color='black', lw=1.0)
show()