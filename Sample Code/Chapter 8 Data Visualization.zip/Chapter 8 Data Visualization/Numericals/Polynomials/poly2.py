from pylab import *

a = 1
b = -2
c = -2
par = [a, b, c]
p = poly1d(par)   # y = ax^2 + bx + c

x = linspace(-3, 3, 101)
y = p(x)

figure()         # create a figure
xlim(xmin=-3.2, xmax=3.2)        # set x-axis range
ylim(ymin=-3.2, ymax=3.2)           # set y-axis range
plot(x, y, 'r')  # create x-y plot using red dot
xlabel('x')      # label x-axis
ylabel('y')      # label y-axis
title('y = a x^2 + b x + c')   #
grid(linestyle='-', linewidth='0.5', color='gray')
axhline(0, color='black', lw=1.0)
axvline(0, color='black', lw=1.0)
show()