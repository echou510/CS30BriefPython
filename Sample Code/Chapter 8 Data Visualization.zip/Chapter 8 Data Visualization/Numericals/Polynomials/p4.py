from pylab import *
from scipy import optimize

def p4(x, a=1, b=0, c=-5, d=0, e=4):
    return a*x**4+b*x**3+c*x**2+d*x+e

# finding roots
x = linspace(-3, 3, 101)
y = p4(x, 1.0, 0.0, -5.0, 0.0, 4.0)
rx = optimize.root(p4, [-2, -1, 1, 2])

print(rx.x)
figure()                         # create a figure
xlim(xmin=-3.2, xmax=3.2)        # set x-axis range
ylim(ymin=-4, ymax=20)           # set y-axis range
plot(x, y, 'r')                  # create x-y plot using red dot
plot(rx.x, p4(rx.x), 'd', ms=10)
xlabel('x')                      # label x-axis
ylabel('y')                      # label y-axis
title('4th order Polynomial x^4 - 5x^2 + 4')   #
grid(linestyle='-', linewidth='0.5', color='blue')
axhline(0, color='black', lw=1.0)
axvline(0, color='black', lw=1.0)
show()
