from pylab import *

a = 1
b = 2
c = 1
d = -4
parN = [a, b]
parD = [c, d]
z = poly1d(parN)   # y = (ax+b)/(cx+d)
p = poly1d(parD)

x = linspace(-30, 30, 101)
y = z(x)/p(x)      # zero over pole

asym = [1] * 101
figure()         # create a figure
xlim(xmin=-25.2, xmax=25.2)        # set x-axis range
ylim(ymin=-25.2, ymax=25.2)           # set y-axis range
plot(x, y, 'r')  # create x-y plot using red dot
plot(x, asym, 'blue', linestyle='-')
xlabel('x')      # label x-axis
ylabel('y')      # label y-axis
title('y = (ax+b)/(cx+d)')   #
grid(linestyle='-', linewidth='0.5', color='gray')
axhline(0, color='black', lw=1.0)
axvline(0, color='black', lw=1.0)
show()