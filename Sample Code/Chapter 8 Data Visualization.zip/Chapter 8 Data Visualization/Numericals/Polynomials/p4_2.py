from pylab import *
import numpy as np

# finding roots
x = linspace(-3, 3, 101)
c = [1, 0, -5, 0, 4]
p = np.poly1d(c)                 # create a numpy polynomial with c
y = p(x)                         # find the y value
rx = np.roots(p)                 # find the roots for the polynomial

print(rx)                        # print roots
figure()                         # create a figure
xlim(xmin=-3.2, xmax=3.2)        # set x-axis range
ylim(ymin=-4, ymax=20)           # set y-axis range
plot(x, y, 'r')                  # create x-y plot using red dot
plot(rx, p(rx), 'd', ms=10)      # plot root locations
xlabel('x')                      # label x-axis
ylabel('y')                      # label y-axis
title('Polynomial x^4 - 5x^2 + 4')   #
grid(linestyle='-', linewidth='0.5', color='blue')
axhline(0, color='black', lw=1.0)
axvline(0, color='black', lw=1.0)
show()

