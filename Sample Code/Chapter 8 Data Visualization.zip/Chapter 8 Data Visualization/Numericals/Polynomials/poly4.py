from pylab import *

a = 1
b = -2
c = -2
d = 1
e = +3
par = [a, b, c, d, e]
p = poly1d(par)   # y = ax^4 + bx^3 + c x^2 + dx + e

x = linspace(-6, 6, 101)
y = p(x)

figure()         # create a figure
xlim(xmin=-5.2, xmax=5.2)        # set x-axis range
ylim(ymin=-5.2, ymax=5.2)           # set y-axis range
plot(x, y, 'r')  # create x-y plot using red dot
xlabel('x')      # label x-axis
ylabel('y')      # label y-axis
title('y =ax^4+bx^3+cx^2+dx+e')   #
grid(linestyle='-', linewidth='0.5', color='gray')
axhline(0, color='black', lw=1.0)
axvline(0, color='black', lw=1.0)
show()