from pylab import *

a = 1
b = -1
par = [a, b]
p = poly1d(par)   # y = ax + b

x = linspace(-4, 4, 101)
y = p(x)

figure()         # create a figure
xlim(xmin=-3.2, xmax=3.2)        # set x-axis range
ylim(ymin=-3.2, ymax=3.2)           # set y-axis range
plot(x, y, 'r')  # create x-y plot using red dot
xlabel('x')      # label x-axis
ylabel('y')      # label y-axis
title('y = a x + b')   #
grid(linestyle='-', linewidth='0.5', color='gray')
axhline(0, color='black', lw=1.0)
axvline(0, color='black', lw=1.0)
show()