# Python program to draw square 
# using Turtle Programming 
import turtle 
skk = turtle.Turtle() 

for i in range(4): 
	skk.forward(50) 
	skk.right(90) 
	
turtle.done() 

