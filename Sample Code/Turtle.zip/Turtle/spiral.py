# Python program to draw 
# Spiral Square Outside In and Inside Out 
# using Turtle Programming 
import turtle #Outside_In 
wn = turtle.Screen() 
wn.bgcolor("black") 
wn.title("Turtle") 
skk = turtle.Turtle() 
skk.color("blue") 

def sqrfunc(size): 
	for i in range(4): 
		skk.fd(size) 
		skk.left(90) 
		size = size-5

def main(): 
        sqrfunc(146) 
        sqrfunc(126) 
        sqrfunc(106) 
        sqrfunc(86) 
        sqrfunc(66) 
        sqrfunc(46) 
        sqrfunc(26)

if __name__ == "__main__":
        main()
