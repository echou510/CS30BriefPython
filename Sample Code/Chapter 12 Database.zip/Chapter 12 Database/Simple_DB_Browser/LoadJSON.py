import json
import pprint

f = open("Student.json", "r")
data_string = f.read()

students = json.loads(data_string)
pprint.pprint(students)

for person in students:
    for key in person:
        print(key,"->",person[key])
    print()

f.close()
