def swap(x, y):
    return (y, x)

t = (1, 2)
t = swap(t[0], t[1])
print(t)
list1 = list(t)
print(list1)
print(len(list1))

t2 = tuple(list1)
print(t2)

s = "ABCDE"
lists = list(s)
print(lists)
listj = "-".join(lists)
print(listj)
wlist = "AA BB CC DD"
lista = wlist.split(" ")
print(lista)
s = "_".join(lista)
print(s)
set1 = {1, 2, 3, 4, 5}
listx = list(set1)
print(listx)
print(1 in set1)
print(1 in listx)
print(listx.index(3))
set2 = {2, 4, 6, 8}
print(set1 | set2)
print(set1 & set2)
print(set1 - set2)


