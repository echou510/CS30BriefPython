s = 'abc'              # single quote, double quote and triple quote are all
t = "abc"              # strings. 
w = '''abcde'''
z = "and;nkafkrjeiwqjjaksdjfk;asj;kjfsd"
print(s)
print(t)
print(w)

k = 'p'                # char is also a string in python
print(k)

print(s[2])            # string has the index access like Java array.

print(w[1:4])          # slicing (substring in Java)
print(w[:])
print(z[1:12])         # substring(1, 12)
print(z[3:])           # substring(3)
print(z[:-5])          # substring(0, s.length()-5)
print(z[-8:-2])        # substring(s.length()-8, s.length()-2)
px = w[1:3]+z[2:-3]
print(px)
