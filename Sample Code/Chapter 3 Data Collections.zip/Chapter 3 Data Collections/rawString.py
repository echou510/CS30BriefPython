sr = r"\n\n\n\\t"
print(sr)
s = "\n\n\n\\t"
print(s)
sb = b"abcdefg"
ss = "abcdefg"
print(sb)
print(ss)

sx = bytes(ss, encoding = "utf8")
print(sx)

s = "*" * 10 + " Washington High School " + "*" * 10
print(s)

