# tuple
#  1. vector
#  2. coordinate
#  3. when you need to return 2 values from a function
import pprint
t = (1, 2)
print(t)

def gcd(n, m):
    if (m==0): return n;
    return gcd(m, n%m)

def swap(a, b):
    return (b, a)

w = (1, 2)
print(w)
w = swap(w[0], w[1])
print(w)

def getInfo():
    name = input("Enter your name: ")
    age  = int(input("Enter your age:"))
    math = int(input("Enter your Math score:"))
    return (name, age, math)

(n, a, m) = getInfo()
print(n)
print(a)
print(m)
y = getInfo()
print(y)

numbers = [1, 2, 3, 4, 5, 6]
letters = ['a', 'b', 'c', 'd', 'e', 'f']
pairs = list(zip(numbers, letters))
pprint.pprint(pairs)
pp = sorted(pairs, key=lambda x: x[1], reverse=True)
pprint.pprint(pp)

first = [t[0] for t in pairs]   # comprehension list 
second = [t[1] for t in pairs]
print(first)
print(second)
