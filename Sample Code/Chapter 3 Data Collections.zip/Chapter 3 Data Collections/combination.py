
def combination(s):
    N = len(s)
    comlist = []
    for i in range(2**N):
        f = '{0:0'+str(N)+'b}'
        e = f.format(i)
        r = ""
        for j in range(len(e)):
            if (e[j]=='0'): r += ""
            else: r += s[j]
        comlist.append(r)
    comlist = sorted(comlist, key = lambda x: len(x), reverse=False)
    return comlist

print(combination("abc"))
