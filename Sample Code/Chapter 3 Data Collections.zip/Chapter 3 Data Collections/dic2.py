# Finite State Machine

lights = {
      'green' : 'yellow',
      'yellow': 'red',
      'red'   : 'green'
    }

state = 'green'
count = 0

while (count<10):
    print(state)
    state = lights[state]    # use current state to go to next state
    count += 1
