# list is array and arraylist

a = [5, 1, 9, 4, 3, 8, 10, 2, 6]

for i in range(len(a)):    # similar to for loop, for each index
    print(a[i], end=" ")   # print means println, print(, end="") means print
print()
print()
for x in a:                # for each element loop
    print(x, end=" ")
print()
print()

sub = a[3: 7]
print(sub)

ary = []

for i in range(4):
    ary.append(i)

print(ary)

s = "abcde"
slist = list(s)
print(slist)
t = "+".join(slist)
print(t)
