# dictionary as a Map
import pprint
s = "safldjka;fkjdas;jf kdsaj;klfjweiojklm;fasj;kjfk;fdask;jfkdsaj;flkdjsa;kfjsad;kljf;dlaskj;klfdsja;lfkjdas  "

d = dict()

for ch in s:
    if (ch not in d.keys()):
        d[ch] = 1
    else:
        d[ch] += 1

pprint.pprint(d)
