# dictionary = object in JavaScript JSON

d = {
      'name' : "Eric",
      'age'  : 15,
      'math' : 100
    }

print(d['name'])
l1 = list(d.keys())
print(l1)
l2 = list(d.values())
print(l2)
print(d['name'])

