fin = open("usdeclar.txt", "r")

ch = fin.read(1)
c = []
f = []
while (ch):
    found = False
    i =0
    while (i < len(c) and not found):
        if ch == c[i]:
            f[i] += 1
            found = True
        i += 1
    if not found:
        c.append(ch)
        f.append(1)
    ch = fin.read(1)

for i in range(len(c)):
    print("Freq[%c]=%d" % (c[i], f[i]))

fin.close()
