for i in range(1, 10):
    for j in range(1, 10):
        print("%3d" % (i*j), end=" ")
    print()


# String.format("%3d", i*j);
# System.out.printf("%3d", i*j); 

print(3*3)
a = 3
print(a*3)
print("%3d" % a*3)
print("K"*10)

