hours = float(input("Enter Hours:"))
rate  = float(input("Enter Rate:"))

print("Your pay is ", end="")
if hours <=0:
    print("0")
elif hours<=40:
    pay = hours * 10
    print(pay)
else:
    pay = 40 * rate + (hours-40) * rate * 1.5
    print(pay)
