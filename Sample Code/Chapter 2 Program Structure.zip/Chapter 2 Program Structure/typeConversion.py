x = 44
sx = str(x)

print(x)
print(type(x))
print(sx)
print(type(sx))
