def max(x, y, z):
    m1 = 0
    if x>=y:
        m1 = x
    else:
        m1 = y
    if (m1>=z): return m1
    else: return z

print(max(1, 2, 3))

