f = open("usdeclar.txt", "r")

text = f.read()   # the file being read in as a string
print(text, end="")

f.close()
