from pylab import * 
def e(x, n):
    sum = 1
    term = 1
    for i in range(1, n+1):
        term = term * x / i
        sum += term
    return sum

x = linspace(-1.0, 1.0, 101)
y = e(x, 20)

figure()
plot(x, y)
show()
