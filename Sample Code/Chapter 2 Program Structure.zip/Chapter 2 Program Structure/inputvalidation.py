def getInt():
    i = 0
    done = False 
    while not done:
        try:
            i = int(input("Enter an Integer: "))
            done = True
        except:
            print("Wrong Input Format")
    return i

N = 3
j = 0
while j<N:
    print(getInt())
    j += 1
