f = open("usdeclar.txt", "r")

for line in f.readlines():
    print(line, end="")
    
f.close()
