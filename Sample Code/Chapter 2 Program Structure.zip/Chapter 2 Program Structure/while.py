query = input("Enter your age: ")
while not query=="quit":
    print(query)
    input("Enter your age: ")
