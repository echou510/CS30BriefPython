import math
def cos(x, n):
    sum = 1
    term = 1
    for i in range(1, n+1):
        term = (-1) * term * x**2/((2*i-1)*(2*i))
        sum += term
    return sum

for i in range(0, 25):
    print("%6.4f" % cos(i*math.pi/12, 100))
