def square(x):
    return x*x

for d in range(10, 1000, 1):
    x = d / 10
    print(square(x))

