f = open("usdeclar.txt", "r")

lines = f.readlines()  # list of lines stored in lines
for line in lines:
    print(line, end="")

f.close()
