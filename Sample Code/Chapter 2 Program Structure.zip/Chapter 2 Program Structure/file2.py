f = open("usdeclar.txt", "r")

line = f.readline()  # None for no more data 
while line:
    print(line, end="")
    line = f.readline()

f.close()
