def grade(score):
    if   score >= 90: return "A"
    elif score >= 80: return "B"
    elif score >= 70: return "C"
    elif score >= 60: return "D"
    return "F"

def main(): 
    for s in range(0, 101, 10):
        print(grade(s))
    
if __name__ == "__main__":
    main()
