def printChange(payment, cost):
    change = payment - cost
    cents = int(change * 100)
    twenty = cents //2000
    cents  = cents % 2000
    ten    = cents //1000
    cents  = cents % 1000
    five   = cents //500
    cents  = cents % 500
    ones   = cents //100
    cents  = cents % 100
    quarter= cents // 25
    cents  = cents %  25
    dime   = cents // 10
    cents  = cents %  10
    nickel = cents //5
    pennies  = cents % 5
    print("Your Product price is : %6.2f" % cost)
    print("Your payment is         %6.2f" % payment)
    print("You change is: ")
    print("   %d twenty dollar bills " % twenty)
    print("   %d ten dollar bills " % ten)
    print("   %d five dollar bills " % five)
    print("   %d one dollar bills " % ones)
    print("   %d quarters " % quarter)
    print("   %d dimes " % dime)
    print("   %d nickels " % nickel)
    print("   %d pennies " % pennies)

def main(): 
    cost = float(input("Enter the cost of your product: "))
    payment = float(input("Enter the payment: "))
    printChange(payment, cost)

if __name__ == "__main__": 
    main()
