
# traffic light in dictionary format
# body {
#  background-color: azure; 
# }
#    Current : Next 
light = {
     "green" : "yellow",
     "yellow" : "red",
     "red": "green"
    }

current = "green"
for i in range(10):
    print(current)
    current = light[current]   # get the next light condition 
