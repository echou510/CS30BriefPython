import pprint
fin = open("usdeclar.txt", "r")

ch = fin.read(1)
table = dict()
while (ch):
    found = False
    i =0
    for letter in table:
        if (ch == letter):
            table[letter] = table[letter]+1
            found = True
        
    if not found:
        table[ch] = 1
    ch = fin.read(1)

pprint.pprint(table)

fin.close()
