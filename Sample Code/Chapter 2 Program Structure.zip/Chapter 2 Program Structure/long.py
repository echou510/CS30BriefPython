s = "sdahfldhsa;fkjds;kaljf;kdsj;akf" + \
    "jds;akjf sd;akjf; dkasj;f jds;a" + \
    "kjfksd;a jfkl;dasj f;jsad; fjks" + \
    "d;jkf sda;kjfds ajkf;dsaj; fsdak"
print(s)
print(s*2) 
