query = input("Enter your age: ")
while query.strip()!="quit":
    print(query)
    input("Enter your age: ")
