from pylab import *
x = linspace(-5, 5, 101)
y = x**2

figure()
bar(x, y)
#scatter(x, y)
show()
