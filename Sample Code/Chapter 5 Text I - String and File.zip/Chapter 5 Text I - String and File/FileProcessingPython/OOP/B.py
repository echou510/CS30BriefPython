from A import *
class B(A):
    def __init__(self, a, b):
        super().__init__(a)      # super(a) in Java
        self.b = b
    def __repr__(self):
        return "(%d, %d)" % (self.a, self.b)

def main():
    aa = A(5)
    bb = B(3, 4)
    print(aa)
    print(bb)

if __name__ == "__main__":
    main()
