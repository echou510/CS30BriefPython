import f1          # not merging namespace
from f2 import *   # merging namespace
import pprint      # not merging
import math as m
import numpy as np
d = dict()
d['a'] = 0
d['b'] = 1
d['c'] = 2

print(a)
print(f1.a)

print(d)
pprint.pprint(d)
print(m.sqrt(2))

ary = np.array([1, 2, 3, 4, 5])
print(ary)