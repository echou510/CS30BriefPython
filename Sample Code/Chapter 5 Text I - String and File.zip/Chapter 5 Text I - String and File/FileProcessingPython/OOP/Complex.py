import math
class Complex:
    """ I am king edward. """
    pi = 3.1415926              # class (cls) variable (static variable better)
    def __init__(self, r=0, i=0):   # constructor
        self.real = r           # real part
        self.img  = i           # imaginary part
    def getReal(self):
        return self.real
    def getImg(self):
        return self.img
    def setReal(self, r):
        self.real = r
    def setImg(self, i):
        self.img = i
    def getAngle(self):
        return math.asin(self.img/math.sqrt(self.real**2+self.img**2)) # sin theta
    def __iadd__(self, other):
        self.real = self.real + other.real
        self.img  = self.img + other.img
        return self
    def __radd__(self, other):
        return Complex(other+self.real, self.img)
    def __add__(self, other):
        if (type(other) == float or type(other)==int):
            return Complex(other + self.real, self.img)
        return Complex(self.real+other.real, self.img+other.img)
    def __eq__(self, other):
        return self.real == other.real and self.img == other.img
    def __repr__(self):         # similar to toString reprint
        return "%.2f+%.2f i" % (self.real, self.img)


def main():
    c1 = Complex(3, 4)
    c2 = Complex(2, 5)
    c3 = Complex(3, 4)
    print(c1)
    print(c1==c2)      # python __eq__   override ==
    print(c1==c3)
    c4 = c1+c2         # python __add__ override +
    print(c4)
    c5 = 4 + c1        # python __radd__ means other c+ right_side complex number
    print(c5)

    c1 += c2           # python __iadd__ override +=
    print(c1)

    print(c1.getAngle()*180/Complex.pi)
    c6 = c1 + 4        # add with type checking   int or float
    print(c6)
    c7 = Complex()
    c8 = Complex(1.0)
    print(c7)
    print(c8)
    c9 = Complex(i=1.0)
    print(c9)
    c10 = Complex(i=10, r=20)
    print(c10)

if __name__ == "__main__":
    main()


