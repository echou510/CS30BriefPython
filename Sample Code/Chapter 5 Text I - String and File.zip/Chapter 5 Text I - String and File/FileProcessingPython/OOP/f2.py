a = 4

def x():
    #global a
    a  = 5
    print(a)

x()
print(a)
x()
