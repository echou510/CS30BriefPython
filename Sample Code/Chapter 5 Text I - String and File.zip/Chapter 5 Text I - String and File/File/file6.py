fin = open("aa.txt", "r")  # fin is the file handler
for line in fin.readlines() :
    line = line.strip()
    print(line)

fin.close()
