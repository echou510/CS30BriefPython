fin = open("aa.txt", "r")  # fin is the file handler
fileStr = fin.read()
print(fileStr)

fin.close()
