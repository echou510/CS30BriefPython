with open("data.csv", "r") as f:
    for line in f: print(line)

        
