fin = open("aa.txt", "r")  # fin is the file handler
lines = fin.readlines()  # one character
for i in range(len(lines)):
    line = lines[i].strip()
    print(line)

fin.close()
