fname = "" # delcare the variable. Wrong type OK
try:
    fname = input("Enter file name: ")
    fin = open(fname, "r")
    # processing here. 
    fin.close()
except:
    print("No such file")

