fin = open("aa.txt", "r")  # fin is the file handler
ch = fin.read(1)  # one character
while ch:
    print(ch, end="")
    ch = fin.read(1)  # one character

fin.close()
