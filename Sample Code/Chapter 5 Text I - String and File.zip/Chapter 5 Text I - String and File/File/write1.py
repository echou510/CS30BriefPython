fout = open("bb.txt", "w")

for i in range(1, 11, 1):
    print("Line ", i, file=fout)

fout.close()
