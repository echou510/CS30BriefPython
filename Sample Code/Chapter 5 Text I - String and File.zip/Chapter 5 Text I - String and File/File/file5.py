fin = open("aa.txt", "r")  # fin is the file handler
lines = fin.readlines()  # one character
for line in lines:
    line = line.strip()
    print(line)

fin.close()
