fin = open("aa.txt", "r")  # fin is the file handler
line = fin.readline().strip()  # line string + '\n'
while line:
    print(line)
    line = fin.readline().strip()  # strip() == trim() in java 

fin.close()
