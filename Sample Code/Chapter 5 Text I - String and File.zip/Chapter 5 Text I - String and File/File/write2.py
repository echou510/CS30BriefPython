fout = open("data.csv", "w")

print("%10s, %3s" % ("Name", "Score"), file=fout);

school = {
 "Ariel": 94,
 "Bryant": 88,
 "Carol": 77,
 "David": 66
}

for n in school: 
    print("%10s, %d" % (n, school[n]), file=fout)
    # String.format("%10s, %d", n, school[n])

fout.close()
