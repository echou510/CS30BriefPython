fin = open("aa.txt", "r")  # fin is the file handler
fileStr = fin.read()
lines = fileStr.split("\n")
print(lines)

fin.close()
