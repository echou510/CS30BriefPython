fin = open("aa.txt", "r")  # fin is the file handler
lines = fin.readlines()  # one character
print(lines)
for line in lines:
    line = line.strip()
    print(line)

fin.close()
