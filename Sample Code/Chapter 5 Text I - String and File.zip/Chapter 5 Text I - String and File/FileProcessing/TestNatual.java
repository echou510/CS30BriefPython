
/**
 * Write a description of class TestNatual here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class TestNatual
{
   public static void main(String[] args){
       System.out.print("\f");
       System.out.printf("%s is a natural number is %b%n", "03", NaturalNumber.isValid("03")); 
       System.out.printf("%s is a natural number is %b%n", "999", NaturalNumber.isValid("999")); 
       System.out.printf("%s is a natural number is %b%n", "0", NaturalNumber.isValid("0")); 
       System.out.printf("%s is a natural number is %b%n", "ab00", NaturalNumber.isValid("ab00")); 
    }
}
