import java.util.*; 
import java.io.*; 
public class Food
{
  int code; 
  String name; 
  String size; 
  int pcode; 
  double grains; 
  double wGrains; 
  double vege; 
  double dkgreen; 
  double orange; 
  double sVege; 
  double oVege; 
  double fruits; 
  double milk; 
  double meat; 
  double soy; 
  double peas; 
  double oil; 
  double fats; 
  double sugar; 
  double alcohol; 
  double calories; 
  double sFats;
  
  Food(int a, String b, String c, int d, 
       double e, double f,double g,double h,double i, 
       double j, double k,double l,double m,double n, 
       double o, double p, double q,double r,double s,
       double t, double u, double v
       )
  {
            code=a; 
            name=b; 
            size=c; 
            pcode=d; 
            grains=e; 
            wGrains=f; 
            vege=g; 
            dkgreen=h; 
            orange=i; 
            sVege=j; 
            oVege=k; 
            fruits=l; 
            milk=m; 
            meat=n; 
            soy=o; 
            peas=p; 
            oil=q; 
            fats=r; 
            sugar=s; 
            alcohol=t; 
            calories=u; 
            sFats=v; 
    }
  public String toString(){
            String s=""; 
            s += "Survey Food Code: "+ code +"\n"; 
            s += "Display Name:     "+ name+"\n"; 
            s += "Portion Size:     "+ size+"\n"; 
            s += "Portion Code:     "+ pcode+"\n"; 
            s += "Grains:           "+ grains+"\n"; 
            s += "Whole Grains:     "+ wGrains+"\n"; 
            s += "Vegetables:       "+ vege+"\n"; 
            s += "DKgreen:          "+ dkgreen+"\n"; 
            s += "Orange:           "+ orange+"\n"; 
            s += "Star. Vegetables: "+ sVege+"\n"; 
            s += "Other Vegetables: "+ oVege+"\n"; 
            s += "Fruits:           "+ fruits+"\n"; 
            s += "Milk:             "+ milk+"\n"; 
            s += "Meat:             "+ meat+"\n"; 
            s += "Soy:              "+ soy+"\n"; 
            s += "Drybeans Peas:    "+ peas+"\n"; 
            s += "Oil:              "+ oil+"\n"; 
            s += "Solid Fats:       "+ fats+"\n"; 
            s += "Added Sugars:     "+ sugar+"\n"; 
            s += "Alcohol:          "+ alcohol+"\n"; 
            s += "Calories:         "+ calories+"\n"; 
            s += "Saturated Fats:   "+ sFats+"\n"; 
       return s; 
    } 
  public static void main() throws Exception{
      System.out.print("\f");
      Scanner input = new Scanner(new File("lu_Condiment_Food_Table.csv")); 
      String[] data_fields = input.nextLine().trim().split(","); 
      int N = data_fields.length; 
      for (int i=0; i<N; i++){
           data_fields[i] = data_fields[i].trim(); 
           //System.out.println(data_fields[i]); 
        }
      //System.out.println(N); 
      int M =0; 
      while (input.hasNext()){
          input.nextLine(); 
          M++; 
        }
      input.close();
      Food[] fa = new Food[M]; 
      input = new Scanner(new File("lu_Condiment_Food_Table.csv")); 
      input.nextLine();  // take out the header line; 
      for (int z=0; z<M; z++){
           String[] tokens = input.nextLine().trim().split(","); 
           int a = Integer.parseInt(tokens[0].trim());  
           String b = tokens[1].trim(); 
           String c = tokens[2].trim(); 
           int d = Integer.parseInt(tokens[3].trim());   
           double e = Double.parseDouble(tokens[4].trim()); 
           double f= Double.parseDouble(tokens[5].trim()); 
           double g= Double.parseDouble(tokens[6].trim()); 
           double h= Double.parseDouble(tokens[7].trim()); 
           double i= Double.parseDouble(tokens[8].trim());  
           double j= Double.parseDouble(tokens[9].trim());  
           double k= Double.parseDouble(tokens[10].trim()); 
           double l= Double.parseDouble(tokens[11].trim()); 
           double m= Double.parseDouble(tokens[12].trim()); 
           double n= Double.parseDouble(tokens[13].trim());  
           double o= Double.parseDouble(tokens[14].trim());  
           double p= Double.parseDouble(tokens[15].trim());  
           double q= Double.parseDouble(tokens[16].trim()); 
           double r= Double.parseDouble(tokens[17].trim()); 
           double s= Double.parseDouble(tokens[18].trim()); 
           double t= Double.parseDouble(tokens[19].trim());  
           double u= Double.parseDouble(tokens[20].trim());  
           double v= Double.parseDouble(tokens[21].trim()); 
           
           Food food = new Food(a, b, c, d, e, f, g, h, i, j, k, l, m, m, o, p, q, r, s, t, u, v); 
           fa[z] = food;
           System.out.println(fa[z]+"\n"); 
        }
      input.close(); 
    }
}
