
public class TestInteger
{
    public static void main(String[] args){
      String s = "11011"; 
      String ex = "^(\\+|-)?(0|([1-9]\\d*))$"; 
      
     boolean svalid = RE.isValid(s, ex); 
     System.out.println(svalid); 
     System.out.println(RE.isValid("000002", ex)); 
     System.out.println(RE.isValid("-333", ex)); 
     String phone = "^[2-9]\\d{2}-\\d{3}-\\d{4}$"; 
     System.out.println(RE.isValid("510-304-9428", phone)); 
     System.out.println(RE.isValid("911", phone)); 
    }
}
