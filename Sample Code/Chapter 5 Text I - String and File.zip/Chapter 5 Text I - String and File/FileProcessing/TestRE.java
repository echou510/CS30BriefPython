
/**
 * Write a description of class TestRE here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class TestRE
{
   public static void main(String[] args){
       System.out.print("\f");
       System.out.printf("%s is a natural number is %b%n", "03", RE.isValid("03", "[1-9][0-9]*")); 
       System.out.printf("%s is a natural number is %b%n", "999", RE.isValid("999", "[1-9][0-9]*")); 
       System.out.printf("%s is a natural number is %b%n", "0", RE.isValid("0", "[1-9][0-9]*")); 
       System.out.printf("%s is a natural number is %b%n", "ab00", RE.isValid("ab00", "[1-9][0-9]*"));
       System.out.printf("%s is a non-negative is %b%n", "0", RE.isValid("0", "0|[1-9][0-9]*"));
       System.out.printf("%s is a integer is %b%n", "0", RE.isValid("0", "0|[-]?[1-9][0-9]*"));
       System.out.printf("%s is a integer is %b%n", "72", RE.isValid("72", "0|[-]?[1-9][0-9]*"));
       System.out.printf("%s is a integer is %b%n", "-72", RE.isValid("-72", "0|[-]?[1-9][0-9]*"));
       System.out.printf("%s is a phone number is %b%n","(510)304-9428",
          RE.isValid("(510)304-9428","^\\(?([0-9]{3})\\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$")
       );
       System.out.printf("%s is a phone number is %b%n","1-886-35-335776",
          RE.isValid("1-886-35-335776","^\\(?([0-9]{3})\\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$")
       );
    }
}
