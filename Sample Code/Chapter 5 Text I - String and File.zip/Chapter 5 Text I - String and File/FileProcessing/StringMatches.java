
public class StringMatches
{    
    public static void main(String[] args){
      System.out.print("\f"); 
      System.out.println("111".matches("^\\d{1,5}$")); 
      System.out.println("11111111111".matches("^\\d{1,5}$")); 
       System.out.println("11111".matches("^\\d{1,5}$")); 
    }
}
