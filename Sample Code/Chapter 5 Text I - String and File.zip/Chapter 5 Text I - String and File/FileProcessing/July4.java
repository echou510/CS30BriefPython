
/**
 * Write a description of class July4 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class July4
{
    public static void main(String[] args){
       System.out.print("\f"); 
       String regex = "Jul(\\s4(th)?|y\\s(4(th)?|(f|F)ourth))"; 
       String[] pats = {"JULY 4", "Jul 4", "July 4", "Jul 4th", "July 4th", "July fourth", "July Fourth", "Jul Fourth"}; 
    
       for (int i=0; i<pats.length; i++){
          System.out.printf("%s is %s\n", pats[i], RE.isValid(pats[i], regex) ? "Legal" : "Illegal"); 
        }
    }
}
