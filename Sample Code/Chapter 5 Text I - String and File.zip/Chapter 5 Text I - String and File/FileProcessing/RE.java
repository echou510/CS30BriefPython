import java.util.regex.Pattern;
import java.util.regex.Matcher;
public class RE
{
    public static boolean isValid(String s, String expression){  
        CharSequence inputStr = s;  
        Pattern pattern = Pattern.compile(expression);  
        Matcher matcher = pattern.matcher(inputStr);  
        return matcher.matches(); 
    } 
}
