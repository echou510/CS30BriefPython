import java.util.regex.Pattern;
import java.util.regex.Matcher;
public class NaturalNumber
{
    public static boolean isValid(String s){  
        //boolean isValid = false;  
        String expression = "[1-9][0-9]*";  
        CharSequence inputStr = s;  
        Pattern pattern = Pattern.compile(expression);  
        Matcher matcher = pattern.matcher(inputStr);  
        /* if(matcher.matches()){  
            isValid = true;  
        }  
        */ 
        return matcher.matches(); 
    } 
}
