import java.util.*; 
import java.io.*; 
public class Splits
{
   public static String int1 = "345, 56, 78, 89"; 
   public static String int2 = "1,2,3,4,5,6"; 
   
   public static void main() throws Exception{
       System.out.print("\f");
       String[] a = int1.split("\\,\\s*"); 
       for (int i=0; i<a.length; i++){
           System.out.println(a[i]+"*****"); 
        }
       String[] b = int2.split("\\,\\s*"); 
       for (int i=0; i<b.length; i++){
           System.out.println(b[i]+"*****"); 
        }
       int line = 1; 
       Scanner input = new Scanner(new File("number.csv")); 
       while (input.hasNext()){
           String[] tokens = input.nextLine().split("\\,\\s*"); 
           int[] data = new int[tokens.length];
           for (int i=0; i<data.length; i++){
               data[i] = Integer.parseInt(tokens[i]);
               System.out.printf("Line %d: data[%d]=%d\n", line, i, data[i]); 
            }
           line++; 
        }
        
       input.close(); 
    }
}
