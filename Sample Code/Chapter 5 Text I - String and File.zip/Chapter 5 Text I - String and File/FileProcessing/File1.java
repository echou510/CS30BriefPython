import java.util.*; 
import java.io.*; 
public class File1
{
    public static void main(String[] args) throws Exception{
      Scanner fin = new Scanner(new File("aa.txt"));
      while (fin.hasNext()){
           String line = fin.nextLine(); 
           System.out.println(line); 
        }
      fin.close(); 
    }
}
