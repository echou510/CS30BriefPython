class atom:
	def __init__(self,atno,x,y,z):
		self.atno = atno
		self.position = (x,y,z)

c = atom(6, 0, 1.0, 2.0)

print(c)