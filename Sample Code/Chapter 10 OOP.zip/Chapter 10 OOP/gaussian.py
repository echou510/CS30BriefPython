from pylab import *
class gaussian:
	def __init__(self, exponent):
		self.exponent = exponent
	def __call__(self, arg):
		return math.exp(-self.exponent*arg*arg)

x = np.linspace(-3.0, 3.0, 61)
y = []
for t in x:
    g = gaussian(1.0)
    y.append(g(t))

y = array(y)
figure()
plot(x, y, '-')
scatter(x, y)
show()
