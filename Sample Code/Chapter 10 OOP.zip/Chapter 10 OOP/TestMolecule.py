from molecule import *
from atom import *

def main():
    mol = molecule('Water')  # defined as before
    at = atom(8, 0.0, 0.0, 0.0)
    mol.addatom(at)
    mol.addatom(atom(1, 0.0, 0.0, 1.0))
    mol.addatom(atom(1, 0.0, 1.0, 0.0))
    print("Water:")
    for a in mol:  # use like a list!
        print("Atom", a.symbol(), ":")
        print("  ", a)

    print("")
    mol[0].translate(1., 1., 1.)
    print(mol[0])

if __name__ == "__main__":
    main()