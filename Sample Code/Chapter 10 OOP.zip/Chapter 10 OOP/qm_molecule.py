from molecule import *
class qm_molecule(molecule):
    def __init__(self, name="Generic", basis="6-31G**"):
        self.basis = basis
        molecule.__init__(self, name)

    def addbasis(self):
        self.basis = []
        for atom in self.atomlist:
            self.basis = add_bf(atom, self.basis)

    def __repr__(self):
        str = 'QM Rules!\n'
        for atom in self.atomlist:
            str = str + 'atom' + '\n'
        return str



