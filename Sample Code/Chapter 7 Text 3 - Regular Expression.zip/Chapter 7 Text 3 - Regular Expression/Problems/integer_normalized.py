# integer_normalized.py
# problme 5:
# regular expression normalized integer
import re
# Sample strings.
list = ["00", "1,000", "33","-102", "3.55", "0", "-32", "+255",
        "4,300", "1,000,000", "22,999,444"]
# Loop.
for element in list:
     # Match if two words starting with letter d.
                  #123456789012345678901
     m = re.match("^(\+|-)?(0|([1-9]\d*))(\,\d{3})*$", element)
     # See if success.
     if m:
           print(m.group(0))