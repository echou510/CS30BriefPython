# goal2.py
# string substitue (replace)
import re

def contract(v):
    p = re.compile(r"go+al")
    v = p.sub("goal", v)
    return v

v = contract("goal gooal gooooooal goooooooal goooooooooal gooal!! gooooooal!! gooal!!!")
print(v)