# train.py
# problem 7:
# regular expression train
import re
# Sample strings.
list = ["EC","EEEPPDBBPDBBBBC","EEBB","EBBBC",
        "EEPPPPPDBBC","EEPPBBC","EEBBDC"]
# Loop.
for element in list:
     # Match if two words starting with letter d.
                  #123456789012345678901
     m = re.match("^E+(P{1,4}D|BB)*C$", element)
     # See if success.
     if m:
           print(m.group(0))