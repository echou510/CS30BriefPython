# java_replacement.py
import re

def calculate_new_string(token):
    ch_list = []
    for j in range(len(token)):
        if (token[j].isupper() and j != 0): ch_list.append(token[j])
    for ch in ch_list:
        token = re.sub(ch, "_" + ch.lower(), token)
    return token

def name_convert(filename1, filename2):
    f1 = open(filename1, "r")
    p = re.compile("[a-z]+([A-Z][a-z0-9_]*)+")
    newlines = []
    for line in f1.readlines():
        # line = line.strip()  Stripping is not needed
        replacement_list = []
        new_list = []
        pos = 0
        m = p.search(line, pos)
        while m:  # find all id's which need to be modifiedd
            pos = m.end()
            replacement_list.append(m.group())
            new_list.append(calculate_new_string(m.group()))
            m = p.search(line, pos)
        # replace all the matched words in the line
        for pair in list(zip(replacement_list, new_list)):
            line = re.sub(pair[0], pair[1], line)
        newlines.append(line)
    f1.close()
    # write to a new file f2
    f2 = open(filename2, "w")
    for line in newlines:
        f2.write(line)
    f2.close()

def main():
    name_convert("Loan.java", "Loan2.java")

if __name__ == "__main__":
    main()