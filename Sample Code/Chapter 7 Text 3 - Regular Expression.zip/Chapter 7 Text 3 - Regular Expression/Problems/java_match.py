# java_match.py
# problme 4:
# regular expression normal integer
import re
# Sample strings.
list = ["javaVariable","computer science","variableA", "floatingNumber", "initialVariableValue"]
# Loop.
for element in list:
     # Match if two words starting with letter d.
                  #123456789012345678901
     m = re.match("[a-z]+([A-Z][a-z0-9_]*)*", element)
     # See if success.
     if m:
           print(m.group(0))