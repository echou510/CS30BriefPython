# clock.py
# problme 2:
# regular expression for July Fourth
import re
# Sample strings.
list = ["1:30pm", "23:18am", "32:00kk", "7:20pm", "10:32am"]
# Loop.
for element in list:
     # Match if two words starting with letter d.
                  #12345678901234567890123456789012
     m = re.match("([1-9]|1[0-2]):[0-5][0-9](a|p)m", element)
     #m = re.match("([2-9]|1[0-2]?):[0-5][0-9](a|p)m", element)
     # See if success.
     if m:
           print(m.group(0))
