# july_fourth.py
# problme 1:
# regular expression for July Fourth
import re
# Sample strings.
list = ["Jul 4", "Jul 4th", "July 4", "July 4th", "Jul Fourth",
        "July Fourth", "jul 4", "July fourth", "j 4", "july Fourth"]
# Loop.
for element in list:
     # Match if two words starting with letter d.
                  #12345678901234567890123
     m = re.match("Jul(\s4(th)?|y\s(4(th)?|(f|F)ourth))", element)
     # See if success.
     if m:
           print(m.group(0))