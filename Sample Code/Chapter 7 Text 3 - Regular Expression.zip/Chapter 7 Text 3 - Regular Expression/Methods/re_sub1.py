import re
# An example string.
v = "running eating reading"
# Replace words starting with "r" and ending in "ing"
# ... with a new string.
v = re.sub(r"r.*?ing", "ring", v)  # #? is using * for lazy algorithm
print(v)
