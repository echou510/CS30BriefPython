import re

print(re.finditer(r'\w','http://www.hackerrank.com/'))
print(map(lambda x: x.group(),re.finditer(r'\w','http://www.hackerrank.com/')))
