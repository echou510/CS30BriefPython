# usdollar.py
# regular expression for US dollar
import re
# Sample strings.
list = ["$0.55", "3.88", "$35", "abd", "zz", "$34.23", "$0.1"]
# Loop.
for element in list:
     # Match if two words starting with letter d.
     m = re.match("(\$(0|[1-9][0-9]*)(\.[0-9]{0,2})?)", element)
     # See if success.
     if m:
           print(m.group(0))