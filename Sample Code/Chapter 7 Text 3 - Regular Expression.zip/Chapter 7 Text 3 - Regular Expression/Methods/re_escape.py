import re
print(re.escape("^a.*$"))

