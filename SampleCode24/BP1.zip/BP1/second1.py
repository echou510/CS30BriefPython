'''
Anything between two quote-quote-quote are block comment 

'''
def welcome(name): 
    print("Welcome to Washington High School, ", name)
    print("Hi, ", name, "Do you like this school?")

print("OK")
welcome("Ariel")
welcome("Betty")
welcome("Carol")
welcome("Daniel")

