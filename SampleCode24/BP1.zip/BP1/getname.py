name = input("Enter Your Name: ") # get a text string
age = int(input("Enter Your Age: ")) # int() convert a string to integer

print(name)
print(type(name))  # should be string
print(age)
print(type(age))   # should be an integer. 
