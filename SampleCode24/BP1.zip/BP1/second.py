print("Welcome to Washington High School, ", "Ariel")
print("Hi, ", "Ariel", "Do you like this school?")


print("Welcome to Washington High School, ", "Betty")
print("Hi, ", "Betty", "Do you like this school?")

print("Welcome to Washington High School, ", "Carol")
print("Hi, ", "Carol", "Do you like this school?")

print("Welcome to Washington High School, ", "Daniel")
print("Hi, ", "Daniel", "Do you like this school?")
