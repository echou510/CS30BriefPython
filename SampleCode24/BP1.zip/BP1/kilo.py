kilo = float(input("Input Weight in kilos: "))

pounds = kilo * 2.205

print(kilo, "kilos is equivalent to ", pounds, "pounds.")
