print("Welcome to Python")                 # "Text Message"
print("This is a beginner's CS course.")
