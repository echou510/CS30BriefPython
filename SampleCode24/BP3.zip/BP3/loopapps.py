# Loop Applications

#

a = [1, 2, 3, 4, 5]
s = 0
for el in a:
    s += el
print("Sum =", s)

m = a[0]
for el in a:
    if el > m: m = el

print("Max =", m)

m = a[0]
for el in a:
    if el < m: m = el

print("Min =", m)

friends = ["Ariel", "Bryant", "Carol", "Daniel"]
for name in friends: # for each loop 
    print(name)
print()

for idx in range(len(friends)):
    print(friends[idx])
print()

n = int(input("Enter an integer: "))
even = 0
odd = 0
while n>=0:
    if n%2==0: even += 1
    else: odd += 1
    n = int(input("Enter an integer: "))

print("There are ", even, "even numbers and ", odd, "odd numbers.")


