n = 0
while n<10: 
    print("Welcome to Python")
    # n += 1

print("Program Stopped")


