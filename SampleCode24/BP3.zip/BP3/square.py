# definition of the square function 
def square(x):
    return x**2

d = square(2)  # d will be the output of the the square function
               # with input of 2

print(d)



    
