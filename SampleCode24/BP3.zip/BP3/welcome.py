# function without return value 
def greeting(name):
    print("Welcome", name)
    print("It is our pleasure to see you.")
    print()

    #print(5) # still part of the function

a = 3 # the function stop before this line
greeting("Mr. Brown")
greeting("Miss Lin")


