# repl.py
# repl loop:
# Read-Eval-Print-Loop
#

n = int(input("Enter an integer: ")) # read
s = 0
while n>=0:  # eval
    print(n) # print
    s += n
    n = int(input("Enter an integer: ")) # loop

print(s) # this program will take many number and calculate its sum
print("Program Terminated")
    
    
