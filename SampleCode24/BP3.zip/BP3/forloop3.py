# break level

for n in range(0, 5):  
    print("Loop ", n, ":")
    if n==3: break  # bypass the loop completely
    print("Welcome to Python")
    print("End of Loop")

print("End of Program")
