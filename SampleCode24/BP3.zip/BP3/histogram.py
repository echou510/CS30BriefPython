a = [1, 2, 3, 4, 1, 2, 4, 1, 2, 3, 3, 1, 2, 1, 0, 0, 4, 1, 2, 4, 0]

h = [0] * 5  # create a list of 5 zeros.  [0, 0, 0, 0, 0]

for el in a:
    h[el]+= 1


for n in range(0, 5):
    print(n, "occurs", h[n], "times")
