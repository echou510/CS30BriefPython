# set1.py
#

a = [1, 2, 3, 2, 3, 1, 4]
sa = set(a)
print(sa)   # {1, 2, 3, 4}
sb ={2, 4, 5}
print(sb)

uab = sa | sb
print(uab)

iab = sa & sb
print(iab)

sa = sa | {5}
print(sa) 
