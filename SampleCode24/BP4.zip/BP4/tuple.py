# tuple.py
#
from math import sqrt

def distance(p1, p2):
    dx = p2[0]-p1[0]
    dy = p2[1]-p1[1]

    return sqrt(dx**2+dy**2)

p1 = (1, 3)
p2 = (4, 5)

print("Point 1: ", p1)
print("Point 2: ", p2)

d = distance(p1, p2)
print("Distance between p1 and p2 is ", d)

