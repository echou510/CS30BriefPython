# list1.py
#
#

list1 = [1, 2, 3, 4]  # creating list by exmaples
print(list1)

# comprehension list
list2 = [t for t in range(4)]  # create a list of [0, 1, 2, 3]
print(list2)

# create list by list() function and append
list3 = list()
print(list3)
list3.append(5)
list3.append(6)
list3.append(7)
print(list3)
