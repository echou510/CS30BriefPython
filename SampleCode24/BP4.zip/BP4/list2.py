# list2.py
# list operations

a = [2, 4, 6, 8, 10]
print("Original list: ", a) 
a.append(12)
print("Append 12 at the end: ", a)
a.pop()
print("Pop out the last element: ", a)
r = a.pop(2)
print(r, "got popped out")
print("After popping index 2 element out: ", a)

a.insert(2, r)
print("Putting the r back to index 2 location: ", a)
b = [1, 3]
c = a+b
print("a+b = ", c)
