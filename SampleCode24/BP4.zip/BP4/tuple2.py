# tuple2.py
#

s = "abcdefg"

t = tuple(s)
print(t)

lt = list(t)
print(lt)

sl = "+".join(lt)
print(sl)


