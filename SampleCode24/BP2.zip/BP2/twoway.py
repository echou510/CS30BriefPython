x = 1
if x>2:
    print('x is bigger')
else:
    print('x is smaller')
    
print('all done') 
