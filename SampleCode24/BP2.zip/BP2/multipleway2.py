x = 22
if x<2:
    print('small')
elif x<10:
    print('medium')
elif x<20:
    print('large')
else:
    print('extra large') 
    
    
print('all done') 
