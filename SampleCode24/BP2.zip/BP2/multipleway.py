x = 14
if x<2:
    print('small')
else:
    if x<10:
        print('medium')
    else:
        print('large') 
    
    
print('all done') 
