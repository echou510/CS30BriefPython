s = "banana"

for ch in s:
    print(ch)

print()

for ch in "banana":
    print(ch)
print()

for i in range(len(s)): # 0, 1, 2, 3, 4, 5
    print(s[i])
print()
