x = 2

size = 'small' if x < 4 else 'large'
print(size) 
