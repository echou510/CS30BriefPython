x = 101
if x>1:
    print("more than 1")
    if x<100:
        print('less than 100')

print('all done')
