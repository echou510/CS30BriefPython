c = int(input("Enter the Celsius Temp: "))
f = c * 1.8 + 32

print(c, "degree C is", f, 'degree F')
print(c, "\u2103 is", f,'\u2109')

