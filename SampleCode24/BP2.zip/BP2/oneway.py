x = 4
print('Before 5')
if x==5:
    print('Is 5')
    print('Is still 5')
    print('Third 5')
print('Afterwards 5')
print()

print('Before 6')
if x==6:
    print('Is 6')
    print('Is still 6')
    print('Third 6')
    
print('Afterwards 6')
