limit = 40 
hour = int(input("Enter Hours: "))
base = int(input("Enter base: "))
extra = base * 1.5

if hour <= 40:
    print("Pay: ", hour*base)
else:
    print("Pay: ", 40*base+(hour-40)*extra)
